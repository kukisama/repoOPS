$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = $utf8NoBom
[Console]::InputEncoding = $utf8NoBom
[Console]::OutputEncoding = $utf8NoBom
$PSNativeCommandUseErrorActionPreference = $false
chcp.com 65001 > $null
Set-Location -LiteralPath 'C:\Users\kukisama\Downloads\Project\longxia'
$promptPath = 'C:\Users\kukisama\Downloads\Project\longxia\.repoops\prompts\a520128951414730827dd3d126dce639\v3\subline\20260314-151818080-subline.md'
$outputPath = 'C:\Users\kukisama\Downloads\Project\longxia\.repoops\v3\runs\a520128951414730827dd3d126dce639\rounds\round-010\subline\subline-output.md'
$prompt = Get-Content -LiteralPath $promptPath -Raw -Encoding utf8
copilot -p $prompt --no-alt-screen --yolo --model gpt-5.4 --add-dir C:\Users\kukisama\Downloads\Project\longxia 2>&1 | Tee-Object -FilePath $outputPath
$exitCode = if ($LASTEXITCODE -eq $null) { 0 } else { $LASTEXITCODE }
exit $exitCode