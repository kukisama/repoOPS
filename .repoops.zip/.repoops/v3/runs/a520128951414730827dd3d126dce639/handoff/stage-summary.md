# V3 Pair Run a520128951414730827dd3d126dce639

- 标题：分析https://github.com/openclaw/openclaw，我希望用.net …
- 目标：分析https://github.com/openclaw/openclaw，我希望用.net 10 和avalonia框架，做一个windows桌面程序，使用现代ui。以此为终极目标开始干把
- 状态：running
- 终极目标状态：INCOMPLETE
- 当前轮次：12/20
- 当前阶段：阶段3：真实能力接入
- 当前阶段目标：在不破坏现有分层、4 页壳与 Infrastructure seam 的前提下，收口阶段3剩余体验与口径问题，把“真实能力已接入”推进到“可按阶段验收放行”。
- 主线：Helm
- 子线：Pathfinder

## 阶段总览

### 阶段1：定边与桌面基线
目标：把 `openclaw/openclaw` 的可复用能力看清楚，明确 Windows 桌面端到底是“控制台/伴生端”还是“全量重写端”，并落下 `.NET 10 + Avalonia` 的最小可运行基线。
完成标志：有明确的产品边界、首版功能清单、关键交互流、技术分层与工程骨架；若仓库仍为空，则应补出最小可启动桌面壳。
明确不做项：不追求全量复刻 upstream，不在本阶段接入全部渠道、语音、移动端能力。

### 阶段2：核心工作台成型
目标：做出可用的桌面工作台，覆盖导航壳、会话/状态总览、配置入口、日志/诊断入口，以及与 Gateway 的适配边界。
完成标志：桌面端可稳定展示核心信息并完成最小主流程，支持 mock/本地适配器切换。
明确不做项：不做全渠道深度联调，不做复杂自动化/插件生态迁移。

### 阶段3：真实能力接入
目标：把 Windows 桌面端接到真实 OpenClaw Gateway/本地运行环境，打通首批高价值能力。
完成标志：至少完成本地实例连接、基础配置管理、状态监控、会话入口、常见诊断操作；具备日常可用性。
明确不做项：不做与 macOS/iOS/Android 的功能对齐，不在此阶段重写 Node/TS 核心运行时。

### 阶段4：发布化与体验抛光
目标：完成安装、升级、异常恢复、UI 一致性、性能与可访问性收口，形成 Windows 可发布版本。
完成标志：具备可分发安装包、稳定启动/升级路径、关键体验指标达标。
明确不做项：不把发布阶段变成架构大改，不额外扩展无关平台。

## 最近一次保留/修正决定

正式保留：
- 保留 `LocalGatewayPathResolver` / `ProcessCommandRunner` / `LocalGatewayCompatibilityProbe` / `LocalGatewayProbeClient` / `LocalGatewayProcessOrchestrator` 这组按职责拆分的 seam 方案。
- 保留“真实 CLI 不可得时使用仅取证的 harness + 可复跑证据文本”的做法；它没有产品化、没有污染现有分层，且本轮已被复跑验证。
- 保留目录预创建已落到真实执行路径这一事实口径：`%AppData%\OpenClaw.Windows` 与 `%LocalAppData%\OpenClaw.Windows\logs` 已可接受。
- 保留本轮对失败可诊断性的收紧：退出码、stderr、日志路径、超时中文摘要都应成为后续基线。
- 保留 `docs\stage2-acceptance-package.md` 的“Stage 2 hold-point / Stage 3 证据另列”澄清方向。
- 保留根目录 `人为参与.md` 中对中文 UI 截图/观察项的补充。

下一轮顺手修：
- 清掉现有 UI 中不该直接暴露给用户的英文/内部术语：`Gateway`、`upstream`、`IGatewayAdapter`、`ViewModel`、`health-check` 等。
- 把 `settings.json` 的展示口径改严谨：目录已预创建可以保留，但若文件尚未落地，不要继续按“用户可直接去看现成文件”表达。
- 对 raw stderr / upstream 原文 / 系统返回值，补“来源 + 中文说明”策略，避免继续半中半英。

冻结不再扩散：
- 不新增页面。
- 不把 harness 产品化。
- 不把进程控制、命令拼接、配置写回塞进 ViewModel。
- 不把当前 process orchestrator 继续堆成单点大类。
- 最新 verdict：REVISE

## 最新摘要

我做了额外验真，不只看子线摘要。

已确认完成的部分：
- `dotnet build .\OpenClaw.Windows.sln` 通过。
- 我亲自复跑了 direct `openclaw doctor` harness，退出码为 `0`。
- 我亲自复跑了 direct `openclaw gateway-daemon` harness（独立端口 `18796`），`/ready` 与 `/healthz` 都返回 `200`，进程在读取输出时持续存活，说明不是“代码存在”而是真能跑。
- 我亲自复跑了 seam success / seam repair，两次 `dotnet run --project ...\SeamRunner.csproj -v q` 都退出 `0`；success 路径给出启动成功与日志落点，repair 路径给出启动失败后的修复执行、退出码与 repair log。
- `%AppData%\OpenClaw.Windows` 与 `%LocalAppData%\OpenClaw.Windows\logs` 当前都真实存在；`gateway-daemon.log`、`gateway-repair.log` 也真实存在并留痕。
- Infrastructure 的失败诊断相比前轮明显收紧：`ProcessCommandRunner` / probe / orchestrator 现在能给出退出码、stderr、失败摘要、日志路径；repair 路径里的超时摘要也已转成中文。

当前不能放行为 ACCEPT 的原因：
- “现有 UI 全中文”仍未完成。当前 4 页与主壳里仍有桌面端自有英文/内部术语直接暴露，不属于必须保留的 CLI 原生命令或协议字段。例如：
  - `MainWindow.axaml` 仍写着 `Gateway`
  - `MainWindowViewModel.cs` 仍写着 `upstream`
  - `ConfigurationPage.axaml` 仍把 `IGatewayAdapter`、`UI` 暴露给用户
  - `DiagnosticsPage.axaml` 仍有 `start/repair/attach/health-check/ViewModel`
- 目录口径基本成立，但文件级口径还不够严谨：目录已创建，`settings.json` 目前并未真实生成，界面/诊断入口若继续按“桌面设置文件可直接查看”表达，容易让人误解成文件已存在。
- repair 结果里仍会直接显示原始 `stderr` 英文内容；这对诊断有价值，但还缺“来源说明 + 中文摘要”的最后一步收口。

结论：本轮已经把阶段3的大头风险基本压下去，尤其 smoke 证据、目录落地、可诊断输出都是真完成；但 UI 中文化和少量口径一致性还没收干净，所以应判为 `REVISE`，再用一轮把体验面收口后进入阶段4热身更稳。
