先把环境根因、仓库现状和验收文档位置一次性摸清，并把执行计划落到会话文件里。接下来我会直接复跑 `dotnet` 证据链，若 NuGet 源为空就先做仓库级修复，再打通运行态。

● SQL: Seed task todos
  └ Executed 2 statement(s)

● Glob "**/{NuGet.Config,nuget.config,Directory.Build.props,Directory.Packages.props,*.sln,*.csproj,
stage2-acceptance-package.md}" in C:\Users\kukisama\Downloads\Project\longxia
  └ 5 files found

● Create plan and capture baseline dotnet state
  $ @'
  # Plan
  1. Capture current .NET SDK and NuGet source state plus restore/build evidence.
  2. Add repository-level NuGet bootstrap if sources are missing, then rerun restore/build.
  3. Run the Avalonia app in local mode, fix runtime blockers without breaking layering, and ...
  └ 216 lines...

已确认根因：`.NET 10.0.201` 在机，但 `dotnet nuget list source` 为空，`NU1100` 与缺源完全一致。现在转去做仓库级 NuGet bootstrap，并同步看运行入口和验收文档，避免只修 `restore` 不修 `run`。

● Todo started: capture-baseline

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

● Read docs\stage2-acceptance-package.md
  └ 221 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 13 lines read

● Read OpenClaw.Windows.sln
  └ 33 lines read

根因修复会先落到仓库本身，而不是要求操作者手动补全全局 NuGet 源。先补项目根的 `NuGet.Config`，让空白机器也能在仓库内复现 `restore/build`。

● Create NuGet.Config

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 35 lines read

● Re-run NuGet source, restore, and build after repo config
  $ dotnet nuget list source; Write-Host '---RESTORE---'; dotnet restore .\OpenClaw.Windows.sln;
  Write-Host '---BUILD---'; dotnet build .\OpenClaw.Windows.sln
  └ 555 lines...

`restore` 已打通，新的阻断是仓库内部编译错误，不是环境问题：`LocalGatewayRuntimeInspector` 的可见性比公开构造函数更低。我先就地修这个真实编译阻断，再继续冲 `run` 和证据包。

● Todo started: fix-nuget-bootstrap

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs lines 1-40
  └ 40 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 126 lines read

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs

环境阻断已经切到源码层，接下来要同时拿两件事：`build` 成功，以及 `local` 模式真实跑起来。然后我会用运行中的壳去找一个不新增页面的真实空态，把证据收进验收包。

● Todo started: fix-nuget-bootstrap

● Glob "src\OpenClaw.Windows.Application\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "src\OpenClaw.Windows.App\**\*.{axaml,cs}" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Build solution after visibility fix
  $ dotnet build .\OpenClaw.Windows.sln
  └ 135 lines...

又发现一个真实编译阻断：`App.axaml.cs` 里的 `Application` 被项目命名空间遮蔽了。这个修复是纯 UI 启动层限定，不碰架构边界。

● Edit src\OpenClaw.Windows.App\App.axaml.cs

✗ Grep "No[A-Z][A-Za-z]+|Empty|Overview|Sessions|Configuration|Diagnostics" in *.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Rebuild after App type fix
  $ dotnet build .\OpenClaw.Windows.sln
  └ 91 lines...

`restore/build` 现在已在本机通过，接下来进入最关键的一步：`local` 真机运行。与此同时我会把页面与空态入口再扫一遍，确保后面能落成“success / failure / empty-state”三类实证。

● Todo started: verify-local-run

● List directory src\OpenClaw.Windows.Application
  └ 6 files found

● List directory src\OpenClaw.Windows.App
  └ 12 files found

● Run Avalonia app in local mode
  $ $env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 1 line...

● Glob "src\OpenClaw.Windows.App\Views\**\*.axaml" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "src\OpenClaw.Windows.Application\State\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "src\OpenClaw.Windows.App\ViewModels\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● List directory src\OpenClaw.Windows.App\ViewModels
  └ 4 files found

● List directory src\OpenClaw.Windows.App\Views
  └ 1 file found

● List directory src\OpenClaw.Windows.Application\State
  └ 1 file found

● List directory src\OpenClaw.Windows.App\ViewModels\Pages
  └ 4 files found

● List directory src\OpenClaw.Windows.App\Views\Pages
  └ 8 files found

● Read shell output: Waiting up to 10 seconds for command output
  └ 107 lines...

应用已在 `dotnet run` 会话中持续运行，说明启动链至少没有立刻崩。现在转去读取窗口/页面代码并抓屏，确认四页壳、失败态和可触发空态的实际呈现。

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

我准备先取一组“当前真实失败态”截图，再切到最小本地假网关 harness 去取“attach/health 成功 + 空态”证据。这样不改 UI，不靠文档推演，直接用运行中的四页壳留证。

● Read src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  └ 64 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Capture window info for running app
  $ Add-Type @'
  using System;
  using System.Runtime.InteropServices;
  public static class Win32 {
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);...
  └ 8 lines...

● Capture failure-run screenshots from Overview and Diagnostics
  $ $evidenceDir = 'C:\Users\kukisama\Downloads\Project\longxia\docs\stage2-evidence'; New-Item
  -ItemType Directory -Force -Path $evidenceDir | Out-Null; Add-Type -AssemblyName
  System.Drawing; Add-Type @'
  using System;
  using System.Runtime.InteropServices;...
  └ 38 lines...

● List directory docs\stage2-evidence

● Read ~\AppData\Local\Temp\copilot-tool-output-1773500837743-h6gf82.txt lines 1-120
  └ 14 lines read

● List directory docs\stage2-evidence

● Read ~\AppData\Local\Temp\copilot-tool-output-1773500837743-h6gf82.txt lines 15-120
  └ 106 lines read

● Capture failure screenshots in a fresh session
  $ $evidenceDir = 'C:\Users\kukisama\Downloads\Project\longxia\docs\stage2-evidence'; New-Item
  -ItemType Directory -Force -Path $evidenceDir | Out-Null; Add-Type -AssemblyName
  System.Drawing; Add-Type @'
  using System;
  using System.Runtime.InteropServices;...
  └ 43 lines...

● List directory docs\stage2-evidence
  └ 2 files found

● Read ~\AppData\Local\Temp\copilot-tool-output-1773500865828-6ftkfq.txt lines 1-40

失败态证据已经开始落地到 `docs\stage2-evidence`。下一步我会切到“最小本地成功 harness”，专门验证 `attach/health` 成功和 Diagnostics 的真实空态。

● Stop shell
  └ 1 line...

● Stop failure-mode app process by window title
  $ $proc = Get-Process | Where-Object { $_.MainWindowTitle -eq 'OpenClaw Windows Workbench' } |
  Select-Object -First 1; if ($proc) { Stop-Process -Id $proc.Id; Start-Sleep -Seconds 1; 'stopped:'
   + $proc.Id } else { 'not-found' }
  └ 2 lines...

我现在切到不改产品代码的最小本地 harness：一个临时 `openclaw.cmd` 加本地 `ready/health` stub。目标不是伪装成 upstream 完整实现，而是把桌面的 `attach/health probe` 真实跑通并拿到空态证据。

● Create temporary fake openclaw CLI on PATH
  $ $harnessDir = 'C:\Users\kukisama\.copilot\session-state\434603e6-e783-484d-8487-6a7d7d53e8a4\f
  iles\local-harness'; New-Item -ItemType Directory -Force -Path $harnessDir | Out-Null; @'
  @echo off
  if "%1"=="--version" echo openclaw-harness 0.0.1
  if "%1"=="gateway-daemon" echo gateway-daemon stub...
  └ 6 lines...

● Start local HTTP stub for ready and health probes
  $ $listener = [System.Net.HttpListener]::new();
  $listener.Prefixes.Add('http://127.0.0.1:18789/'); $listener.Start(); Write-Host
  'HARNESS_READY'; while ($listener.IsListening) { $context = $listener.GetContext(); try {
  $path = $context.Request.Url.AbsolutePath.ToLowerInvariant(); switch ($path) { '/ready' {
  $statusCode = 200; $body = '{"status":"ready"}' } '/readyz' { $statusCode = 200; $body = ...
  └ 8 lines...

● Read ~\.copilot\session-state\434603e6-e783-484d-8487-6a7d7d53e8a4\files\local-harness\openclaw.cmd

  └ 3 lines read

● Read shell output: Waiting up to 10 seconds for command output
  └ 2 lines...

本地 stub 已经在 `127.0.0.1:18789` 起好，并且临时 `openclaw.cmd` 已放进会话 harness 目录。现在重跑 `local` 模式应用，专门验证真实的 `attach/health` 成功态。

● Verify harness endpoints directly
  $ $ready = Invoke-WebRequest 'http://127.0.0.1:18789/ready' -UseBasicParsing; $health =
  Invoke-WebRequest 'http://127.0.0.1:18789/healthz' -UseBasicParsing; [pscustomobject]@{
  ReadyStatus = $ready.StatusCode; ReadyBody = $ready.Content; HealthStatus = $health.StatusCode;
  HealthBody = $health.Content } | Format-List
  └ 5 lines...

● Run app in local mode against harness
  $ $env:PATH='C:\Users\kukisama\.copilot\session-state\434603e6-e783-484d-8487-6a7d7d53e8a4\files\l
  ocal-harness;' + $env:PATH; $env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 1 line...

● Find running app window for success capture
  $ Get-Process | Where-Object { $_.MainWindowTitle -eq 'OpenClaw Windows Workbench' } |
  Select-Object Id, ProcessName, MainWindowTitle, MainWindowHandle
  └ 4 lines...

● Read shell output: Waiting up to 10 seconds for command output
  └ 97 lines...

为了避免盲点坐标，我先直接读一遍运行中窗口的自动化树；如果 Avalonia 暴露了导航项名字，就能更稳地选中 `Sessions / Configuration / Diagnostics` 再抓图。

● List automation tree for running app window
  $ Add-Type -AssemblyName UIAutomationClient; Add-Type -AssemblyName UIAutomationTypes; $proc =
  Get-Process | Where-Object { $_.MainWindowTitle -eq 'OpenClaw Windows Workbench' } |
  Select-Object -First 1; if (-not $proc) { throw 'window not found' }; $root =
  [System.Windows.Automation.AutomationElement]::FromHandle($proc.MainWindowHandle); $walker =
  [System.Windows.Automation.TreeWalker]::RawViewWalker; function ...
  └ 15 lines...

● Read shell output: Waiting up to 10 seconds for command output
  └ 2 lines...

● Capture success and empty-state screenshots from running harness app
  $ $evidenceDir = 'C:\Users\kukisama\Downloads\Project\longxia\docs\stage2-evidence'; New-Item
  -ItemType Directory -Force -Path $evidenceDir | Out-Null; Add-Type -AssemblyName
  System.Drawing; Add-Type @'
  using System;
  using System.Runtime.InteropServices;...
  └ 48 lines...

● List directory docs\stage2-evidence
  └ 6 files found

● Read ~\AppData\Local\Temp\copilot-tool-output-1773500984274-yzousa.txt lines 1-30
  └ 1 line read

除截图外，我还想补一条“可机读”的运行证据：直接从 Infrastructure/Application 层拉一次快照，确认成功态下 `Gateway attached`、`BlockingItems=0`、`Sessions=3`，这样验收包不会只靠图片。

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● List directory src\OpenClaw.Windows.Application\Abstractions
  └ 4 files found

● List directory src\OpenClaw.Windows.Application\Models
  └ 1 file found

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 97 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDesktopWorkbenchService.cs
  └ 8 lines read

● List built app output for assembly loading
  $ Get-ChildItem .\src\OpenClaw.Windows.App\bin\Debug\net10.0 | Select-Object Name | Format-Table
  -HideTableHeaders
  └ 37 lines...

● Collect machine-readable snapshot facts from infrastructure service
  $ $env:PATH='C:\Users\kukisama\.copilot\session-state\434603e6-e783-484d-8487-6a7d7d53e8a4\files
  \local-harness;' + $env:PATH; $env:OPENCLAW_WINDOWS_MODE='local'; $bin =
  'C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.App\bin\Debug\net10.0';
  [System.Reflection.Assembly]::LoadFrom((Join-Path $bin
  'Microsoft.Extensions.DependencyInjection.Abstractions.dll')) | Out-Null; ...
  └ 25 lines...

● Read ~\AppData\Local\Temp\copilot-tool-output-1773501033495-a3uf70.txt lines 1-80
  └ 4 lines read

截图证据已经够基本可用，但我还想补一条更硬的事实链：直接从 `LocalGatewayRuntimeInspector` 和 `LocalDiagnosticsAdapter` 读出运行结果，确认成功态不是“看起来像成功”，而是真的返回了 `Gateway attached / 0 blockers`。

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  └ 38 lines read

● List relevant runtime types from infrastructure assembly
  $ $bin =
  'C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.App\bin\Debug\net10.0'; $asm
   = [System.Reflection.Assembly]::LoadFrom((Join-Path $bin
  'OpenClaw.Windows.Infrastructure.dll')); $asm.GetTypes() | Where-Object { $_.FullName -match
  'ResolvedWorkbenchMode|DesktopWorkbenchModeResolver|LocalGatewayRuntimeInspector|LocalDiagnost...
  └ 68 lines...

我顺手把唯一一个编译 warning 也收掉，避免验收时被误判成“还有未整理的工具链问题”。这不改行为，只修空引用分析噪音。

● Edit src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs

成功态证据已经取完，我先把临时 harness 和运行中的窗口收掉，再回到“机器默认状态”复跑一遍真实失败探针，把两种状态都留在文档里。

● Stop shell
  └ 1 line...

● Stop shell
  └ 1 line...

● Stop any remaining OpenClaw app window
  $ $proc = Get-Process | Where-Object { $_.MainWindowTitle -eq 'OpenClaw Windows Workbench' } |
  Select-Object -First 1; if ($proc) { Stop-Process -Id $proc.Id; 'stopped:' + $proc.Id } else {
  'not-found' }
  └ 2 lines...

我在补最后一块“终端留证”：把环境命令、`restore/build`、当前失败探针，以及一次带最小 harness 的 `run` 过程都写进同一个文本证据文件，便于 Helm 直接复核。

● Read src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  └ 65 lines read

● Capture terminal evidence into docs\stage2-evidence\terminal-evidence.txt
  $ $evidenceDir = 'C:\Users\kukisama\Downloads\Project\longxia\docs\stage2-evidence'; $transcript
   = Join-Path $evidenceDir 'terminal-evidence.txt'; $harnessDir = 'C:\Users\kukisama\.copilot\s
  ession-state\434603e6-e783-484d-8487-6a7d7d53e8a4\files\local-harness'; New-Item -ItemType
  Directory -Force -Path $evidenceDir | Out-Null; @'
  @echo off...
  └ 64 lines...

● List directory docs\stage2-evidence
  └ 7 files found

● Read docs\stage2-evidence\terminal-evidence.txt lines 1-220
  └ 67 lines read

● Read ~\AppData\Local\Temp\copilot-tool-output-1773501132002-ondqw4.txt lines 1-120
  └ 7 lines read

我现在把事实收口到仓库文档：根目录排障说明、阶段2验收包、以及一份可直接审阅的终端证据文本。口径会明确区分“默认机器真实失败”和“最小 local harness 成功”。

● Create WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md
  Edit docs\stage2-acceptance-package.md
  Delete docs\stage2-evidence\terminal-evidence.txt
  Create docs\stage2-evidence\terminal-evidence.txt

文档口径已经按“SDK 成功机 + 仓库级 NuGet 修复 + local attach/health 真实证据 + start/repair 仍缺”重新收口。最后我再做一次干净的 `build` 和文件核对，然后就给主线交付。

● Todo completed: verify-local-run, update-docs

● List directory docs\stage2-evidence
  └ 7 files found

● Read WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md
  └ 66 lines read

● Read docs\stage2-acceptance-package.md lines 1-260
  └ 162 lines read

● Read docs\stage2-evidence\terminal-evidence.txt
  └ 88 lines read

● Run final build validation
  $ dotnet build .\OpenClaw.Windows.sln
  └ 388 lines...

我刚抓到一个非代码阻断：不是编译问题，而是我前面取证时拉起的 `PowerShell` 子进程锁住了 `OpenClaw.Windows.Infrastructure.dll`。先把这个残留进程收掉，再补一遍干净 `build`，避免把取证副作用留给主线。

✗ Inspect and stop locking PowerShell process
  $ $proc = Get-Process -Id 4648 -ErrorAction SilentlyContinue; if ($proc) { $proc | Select-Object
  Id, ProcessName, StartTime, MainWindowTitle; Stop-Process -Id $proc.Id; 'stopped:' + $proc.Id }
  else { 'locking-process-not-found' }
  Command not executed. The 'Stop-Process' command must specify at least one process using -Id
  <PID>.

● List shells
  └ Active shell sessions:

锁文件的就是我自己的旧 `stage2-main` PowerShell 会话，不是项目残留进程。把这个会话结束掉之后，再用新会话做最终 `build` 才是干净结果。

● List shells
  └ <no active shell sessions>

● Stop shell
  └ 1 line...

● List directory docs\stage2-evidence
  └ 7 files found

● Final clean build in a fresh shell
  $ dotnet build .\OpenClaw.Windows.sln
  └ 574 lines...

STATUS: DONE
SUMMARY:
<<<SUMMARY
本轮已把阶段2当前主阻断从“环境不明”收口为“仓库级可复现解决方案 + 真实运行证据”。我补了根目录 `NuGet.Config`，在已装 `.NET 10.0.201 SDK` 的机器上实际跑通了 `dotnet --list-sdks`、`dotnet nuget list source`、`dotnet restore`、`dotnet build`，并修掉了两处源码级编译阻断与一处工具链 warning。随后实际执行了 `local` 模式 `dotnet run`，拿到了默认机器真实失败态，以及基于最小本地 harness 的真实 attach/health 成功态和 Diagnostics 空态证据；同时把根目录排障文档、终端证据、阶段2验收包口径全部更新为新的 hold-point 版本。
SUMMARY>>>
FACTS:
<<<FACTS
1. 仓库级 NuGet 根因修复已落地：
- 新增 `NuGet.Config`
- 作用：在全局 `dotnet nuget list source` 为空的机器上，仓库内仍能解析 `nuget.org`
- 复跑结果：`dotnet nuget list source` 现在显示 `https://api.nuget.org/v3/index.json`

2. 真实执行并通过的命令链：
- `dotnet --list-sdks` → `10.0.201 [C:\Program Files\dotnet\sdk]`
- `dotnet nuget list source` → 已显示 `nuget.org`
- `dotnet restore .\OpenClaw.Windows.sln` → 成功
- `dotnet build .\OpenClaw.Windows.sln` → 最终在新 shell 中成功

3. 本轮直接修掉的源码阻断：
- `src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs`
  - 将 `LocalGatewayRuntimeInspector` 调整为 `public sealed class`
  - 保持 `InspectAsync` 为 `internal`
  - 目的：修复 public 构造函数参数可见性不一致导致的 `CS0051`
- `src\OpenClaw.Windows.App\App.axaml.cs`
  - `App` 从 `Avalonia.Application` 继承
  - 目的：修复项目命名空间 `Application` 遮蔽导致的 `CS0118`
- `src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs`
  - 消除空值分析 warning，避免把工具链噪音留到验收

4. 真实运行态证据已补齐：
- 默认机器真实失败态：
  - `node.exe` 在 PATH
  - `openclaw` 不在 PATH
  - `http://127.0.0.1:18789/ready` 拒绝连接
  - `http://127.0.0.1:18789/healthz` 拒绝连接
- local 成功态：
  - 用临时 harness 提供 `openclaw.cmd`
  - 本地 HTTP stub 对 `/ready`、`/readyz`、`/health`、`/healthz` 返回 200
  - 执行 `\$env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
  - 成功拉起桌面窗口，实测窗口进程：`OpenClaw.Windows.App`
- empty-state：
  - 在 harness 成功态下，Diagnostics 的 blockers 为空，作为真实可触发空态留证

5. 新增/更新文档与证据：
- 新增根目录：`WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md`
  - 明确记录：
    - 未装 SDK 时 `restore/build/run` 会直接失败
    - 已装 SDK 但 NuGet 源缺失时会出现 `NU1100`
  - 包含最短排查链路：
    - `dotnet --list-sdks`
    - `dotnet nuget list source`
    - `dotnet restore`
- 更新：`docs\stage2-acceptance-package.md`
  - 已改为新的最终阶段2 hold-point 口径
  - 明确写清：
    - 当前机器是 `.NET 10 SDK` 成功机
    - local 真实已有的是 `attach/health probe`
    - `start/repair orchestration` 仍缺，且缺口留在 `IGatewayAdapter`
    - SDK/NuGet source 根因与仓库级处理方式已在根目录留痕
- 证据目录：`docs\stage2-evidence`
  - `overview-local-failure.png`
  - `diagnostics-local-failure.png`
  - `overview-local-success.png`
  - `sessions-local-success.png`
  - `configuration-local-success.png`
  - `diagnostics-local-empty-state.png`
  - `terminal-evidence.txt`

6. 分层红线未破坏：
- 模式切换仍在 Infrastructure
- PATH/HTTP probe/SDK 检查仍在 Infrastructure
- 未把进程/网络/配置逻辑回灌进 ViewModel
- `start/repair orchestration` 仍未上卷到 UI
FACTS>>>
ADJUSTMENTS:
<<<ADJUSTMENTS
1. 顺手修了 `DotNetSdkProbe` 的 nullable warning，避免验收时把 warning 误判为工具链未收口。
2. 为了拿到真实 success/empty-state 证据，我没有改 UI 页面，也没有改 ViewModel 行为；而是用会话级临时 harness（临时 `openclaw.cmd` + 本地 HTTP stub）去真实触发现有 `attach/health` seam。
3. 取证过程中曾出现我自己启动的 PowerShell 子进程锁住 `OpenClaw.Windows.Infrastructure.dll`，导致一次复验 build 失败；已明确识别为取证副作用，并通过关闭旧 shell 后在新 shell 中复跑 `dotnet build` 成功收口。
ADJUSTMENTS>>>
QUESTIONS:
<<<QUESTIONS
无
QUESTIONS>>>
NEXT:
<<<NEXT
1. 若主线继续推进，优先进入 `IGatewayAdapter` 内的 `start/repair orchestration`，保持不回渗 UI。
2. 其次补 `openclaw --version` / CLI 兼容性检查，以及日志路径与常见诊断动作。
3. 若 Helm 需要更硬的 success 证据，可再补一轮“真实 upstream gateway-daemon”而非临时 harness 的本机联通证据，但那已属于阶段3预热深水区。
NEXT>>>


Total usage est:        1 Premium request
API time spent:         8m 36s
Total session time:     11m 57s
Total code changes:     +266 -228
Breakdown by AI model:
 gpt-5.4                 3.0m in, 34.9k out, 2.9m cached (Est. 1 Premium request)
