我先快速复核项目现状和依赖配置，把“SDK 问题已解、现在真正的新阻断是什么”判断清楚，再给下一轮任务卡收口。

● SQL: Create planning todos
  └ 2 row(s) inserted. Last inserted row ID: 2.

● Read OpenClaw.Windows.sln
  └ 33 lines read

● Read docs\stage2-acceptance-package.md
  └ 221 lines read

● Grep "TargetFramework|TargetFrameworks|PackageReference|RestoreSources|packageSources|PackageSourc
eMapping" in *.{csproj,props,targets,config} (C:\Users\kukisama\Downloads\Project\longxia)
  └ 11 lines found

● Glob "**/*.{csproj,props,targets,config,md,sln}" in C:\Users\kukisama\Downloads\Project\longxia
  └ 46 files found

我已经把阻断从“没 SDK”推进到了“NuGet 还原/运行时问题”，这轮值得继续：现在问题可执行、可修复，而且可以和阶段 2 验收证据一起收口。

● Todo started: review-current-blockers

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 13 lines read

● Read src\OpenClaw.Windows.Application\OpenClaw.Windows.Application.csproj
  └ 7 lines read

● Read docs\desktop-baseline.md
  └ 167 lines read

我再补一刀环境核实：确认现在是不是已经进到了“SDK 已有、NuGet 源/包兼容出问题”的新阶段，这会决定任务卡是修环境还是直接修工程。

● Check SDK and NuGet sources
  $ dotnet --list-sdks; Write-Host '---'; dotnet --info; Write-Host '---'; dotnet nuget list source
  └ 30 lines...

STATUS: PLAN

STAGE_PLAN:
<<<STAGE_PLAN
无
STAGE_PLAN>>>

CURRENT_STAGE: 阶段2：核心工作台成型

STAGE_GOAL: 在已装 `.NET 10 SDK` 的 Windows 机器上清掉 NuGet 还原与运行时阻断，补齐 `restore/build/run` 成功证据与 local 模式最小真实运行证据包，推动阶段2达到可验收收口条件。

ARCH_GUARDRAILS:
<<<ARCH_GUARDRAILS
无
ARCH_GUARDRAILS>>>

ROUND_GOAL: 先把“已装 SDK 但无法还原/运行”的新阻断彻底打穿，并把结果沉淀成可复现的仓库级事实与阶段2验收证据。

TASK_CARD:
<<<TASK_CARD
1. 阻断先修：在当前已装 `.NET 10.0.201 SDK` 的 Windows 机器上，先留存并复跑 `dotnet --list-sdks`、`dotnet nuget list source`、`dotnet restore .\OpenClaw.Windows.sln`、`dotnet build .\OpenClaw.Windows.sln`。现阶段优先判断为 **NuGet 源未配置/仓库未自带源声明**，不是继续纠缠“缺 SDK”。若 `dotnet nuget list source` 仍为空，则直接修到仓库级可复现方案：优先补项目根目录可控的 NuGet 源配置或等价 bootstrap 方案，再复跑 restore/build；不得通过降级 `.NET 10`、替换 Avalonia、漂移到别的 UI 栈来绕过。

2. 根目录留痕：按主线要求，在**项目根目录**新增一份环境教训/启动排障文档，文件名可自定，但必须明确记录两类已踩坑事实与处理命令：
   - 未安装 `.NET SDK` 时，`restore/build/run` 会直接失败；
   - 已安装 SDK 但 NuGet 源缺失时，会出现当前这类 `NU1100`“无法解析 net10.0 包”错误。
   文档必须给出最短排查链路：`dotnet --list-sdks`、`dotnet nuget list source`、`dotnet restore`，以及对应修复动作。口径要面向“未来同类机器如何一步处理”，不要写成事后总结散文。

3. 运行态继续推进：一旦 restore/build 打通，立即执行
   `\$env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
   对“程序本身报错”直接处理，不要另起轮次。凡是阻断 local 运行证据的运行时异常、依赖注入异常、配置异常、空引用、路径探测问题，都允许子线同轮直接修掉；但必须守住分层红线，不能把进程/网络/配置写回灌进 ViewModel。

4. 证据包补齐：在成功机上把 4 页最小真实证据包补成**真实运行态证据**，至少覆盖：
   - local 成功态；
   - 当前真实失败态；
   - 一个真实可触发的 empty-state；
   - 终端留证（restore/build/run + 环境命令）与最少必要截图/录屏帧。
   不新增页面；继续使用 `Overview / Sessions / Configuration / Diagnostics` 四页壳完成取证。

5. 验收包更新：把 `docs\stage2-acceptance-package.md` 改成新的最终阶段2口径，明确写清：
   - 当前机器已是 `.NET 10 SDK` 成功机还是仍需额外环境动作；
   - local 模式真实已有的是 `attach/health probe`；
   - `start/repair orchestration` 仍缺，且缺口继续留在 `IGatewayAdapter` seam；
   - 这次新增的“SDK / NuGet source”根因与仓库级处理方式，已在项目根目录文档留痕。
   若成功证据仍不全，继续维持 hold-point 写法，不准提前宣称阶段2完成。

6. 非阻断并入同轮：若上述阻断与证据已完成，允许把阶段3预热项顺手并入同一轮，但只限 existing seam 内推进，不开新页、不回渗 UI：
   - `IGatewayAdapter` 的 start/repair orchestration；
   - CLI / 版本兼容检查；
   - 日志路径与常见诊断动作。
   若时间冲突，优先级始终低于 restore/build/run 成功证据与 local 真实运行证据。

7. 小问题处理原则：本轮起对“小而真”的阻断 bug 不单独浪费轮次。只要问题直接影响阶段2 runnable proof、local 证据或文档口径，就地修、同轮验；只有涉及产品边界漂移或架构红线破坏时，才上提主线复判。
TASK_CARD>>>

REVIEW_FOCUS:
<<<REVIEW_FOCUS
1. `NU1100` 是否被准确判定并修到根因：重点看 `dotnet nuget list source` 是否已不再为空，或仓库是否已提供可复现的源配置/bootstrap，而不是仅靠口头说明。
2. 是否拿到了真实 `.NET 10 SDK` 机器上的 `restore/build/run` 成功证据，以及 local 模式 4 页真实 success / failure / empty-state 证据。
3. 运行时错误是否已被同轮处理，同时仍然守住“进程/网络/配置逻辑不进 ViewModel”的分层红线。
4. 项目根目录是否已留下可复用的环境排障文档，并且 `docs\stage2-acceptance-package.md` 已与之形成一致口径。
5. 如顺手推进阶段3，是否严格停在 `IGatewayAdapter` / Infrastructure seam，没有页面扩散和全局 God Service 回潮。
REVIEW_FOCUS>>>

SUMMARY:
<<<SUMMARY
值得继续推进，而且这轮要比上一轮更激进。因为主阻断已经不是“缺 SDK”这种外部前提，而是一个可落在仓库与环境 bootstrap 层的真实工程问题：当前机器已装 `.NET 10.0.201 SDK`，但 `dotnet nuget list source` 返回“找不到任何源”，这与用户给出的 `NU1100` 现象是对得上的。也就是说，阶段2现在卡的是“仓库如何在成功机上稳定 restore/build/run 并留痕”，不是架构方向错误。

主线判断因此更新为：继续推进，且本轮必须把“SDK 缺失教训 + NuGet 源缺失教训”沉淀到项目根目录，同时把 restore/build/run 成功证据和 local 真实运行证据一并拿下。程序运行中的小阻断可直接同轮修复，不必再拆轮次；但阶段2在拿到真实成功证据前，仍不得宣称完成。
SUMMARY>>>


Total usage est:        1 Premium request
API time spent:         1m 26s
Total session time:     1m 36s
Total code changes:     +0 -0
Breakdown by AI model:
 gpt-5.4                 116.7k in, 5.3k out, 100.2k cached (Est. 1 Premium request)
