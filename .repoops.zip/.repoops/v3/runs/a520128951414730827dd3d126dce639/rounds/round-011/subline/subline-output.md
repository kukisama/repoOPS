先快速摸清项目结构和现状，再落计划、补证据链与中文化改动。之后我会直接实现并跑 build/smoke。

● SQL: Seed phase3 todos
  └ Executed 2 statement(s)

● Glob "docs/*.md" in C:\Users\kukisama\Downloads\Project\longxia
  └ 2 files found

● Glob "src/**/*.axaml" in C:\Users\kukisama\Downloads\Project\longxia
  └ 8 files found

● Grep "gateway-daemon|doctor|ProcessCommandRunner|Orchestrator|Compatibility|log|AppData|LocalAppDa
ta|OpenClaw.Windows|Start|Repair|Diagnostics|Configuration" in src/**/*.{cs,axaml,md}
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 47 files found

● Glob "src/**/*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ 47 files found

我已定位到阶段3相关实现都在现有 seam 里，接下来先补一个可追踪计划，然后集中查看关键 Infrastructure、ViewModel、AXAML 与文档。

● Create ~\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\plan.md

● Read src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  └ 164 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  └ 313 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs
  └ 164 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 30 lines read

● Read docs\stage2-acceptance-package.md
  └ 190 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 155 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayPathResolver.cs
  └ 35 lines read

● Read 人为参与.md
  └ 71 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 220 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  └ 25 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 159 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

我已经看到两个问题同时存在：一是大量用户可见英文还在 ViewModel/Infrastructure 文案里，二是进程层有多个静默 `catch`。下面继续把剩余 UI 面和模型文案一次看全。

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  └ 28 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 97 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

✗ Grep ""[^"]*[A-Za-z][^"]*"" in **/*.{cs,axaml} (C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

我接下来切到实现前的最后一轮核对：把 mock/local 两套用户文案都查清，并确认当前机器上真实 CLI/Node/.NET 的可用性，避免后面改完还拿不到 smoke 证据。

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 91 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 29 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 93 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  └ 38 lines read

● Read src\OpenClaw.Windows.Infrastructure\ResolvedWorkbenchMode.cs
  └ 8 lines read

● Check dotnet node openclaw availability
  $ $ErrorActionPreference='Stop'; Write-Host "CWD: $(Get-Location)"; $cmds =
  'dotnet','node','openclaw'; foreach ($c in $cmds) { $g = Get-Command $c -ErrorAction
  SilentlyContinue; if ($null -eq $g) { Write-Host "MISSING $c" } else { Write-Host "FOUND $c ->
   $($g.Source)" } }; if (Get-Command dotnet -ErrorAction SilentlyContinue) { dotnet --list-sdks
   }; if (Get-Command node -ErrorAction SilentlyContinue) { node --version }; if (Get-Command ...
  └ 8 lines...

我先跑一遍当前基线 build，避免把历史问题误算到本轮改动里；之后就直接落代码和 smoke harness。

● SQL: Mark verify todo pending
  └ 1 row(s) updated.

● Build solution baseline
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 500 lines...

● Read src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  └ 65 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  └ 25 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.App\ViewModels\NavigationItemViewModel.cs
  └ 20 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

● Read src\OpenClaw.Windows.App\Program.cs
  └ 19 lines read

我开始落代码了，先把“状态文案/模式判断/启动基线”这条主干改成中文且可维护，再处理 orchestrator 与文档。

● Edit src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  Edit src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  Edit src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs

✗ Edit src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  Edit src\OpenClaw.Windows.App\MainWindow.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  Edit docs\stage2-acceptance-package.md
  Edit 人为参与.md
  Failed to apply patch: Error: Failed to find expected lines in
  C:\Users\kukisama\Downloads\Project\longxia\docs\stage2-acceptance-package.md:
  - `start/repair orchestration` is still not implemented

大补丁冲突了，我改成分批落地，避免误伤。先把进程诊断、目录/模式配置和核心适配器逐个收紧。

✗ Edit src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  Failed to apply patch: Error: Failed to find expected lines in C:\Users\kukisama\Downloads\Project
  \longxia\src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs:
  internal sealed record ProcessCommandResult(
      bool Started,
      int? ExitCode,
      string StandardOutput,
      string StandardError,
      string? FailureReason)
  {
      public bool Succeeded => Started && ExitCode == 0;

      public string CombinedOutput
      {
          get
          {

● Read src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs lines 1-145
  └ 145 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs lines 117-132
  └ 16 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 31 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 33 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  └ 322 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 220 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 155 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 92 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 98 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read docs\stage2-acceptance-package.md lines 1-30
  └ 29 lines read

● Read docs\stage2-acceptance-package.md lines 135-190
  └ 56 lines read

● Read 人为参与.md
  └ 71 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

我补一轮“漏网英文”清扫：除了文档口径，还把 `Adoption` 枚举在总览页的英文显示问题一起收掉，避免 UI 还冒出 `DirectReuse` 这类词。

● Edit src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit docs\stage2-acceptance-package.md
  Edit 人为参与.md

我先跑一轮文本扫描，专抓剩余用户可见英文，然后在 build 前做最后一遍文案收口。

● Scan source for remaining English UI strings
  $ $ErrorActionPreference='Stop'; $files = Get-ChildItem -Path '.\src' -Recurse -Include
  *.cs,*.axaml | Where-Object { $_.FullName -notmatch '\\obj\\|\\bin\\' }; foreach ($file in
  $files) { $matches = Select-String -Path $file.FullName -Pattern '"[^"]*[A-Za-z][^"]*"'
  -AllMatches; foreach ($m in $matches) { foreach ($g in $m.Matches) { if ($g.Value -match
  'using |namespace |x:Class=|xmlns|net10|node\.exe|openclaw|gateway-daemon|healthz|ready|dotnet...
  └ 10 lines...

● Read ~\AppData\Local\Temp\copilot-tool-output-1773503156316-urea1k.txt lines 1-220
  └ 214 lines read

● Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml

代码面基本收口，我先编译确认没有把模型/文案改坏；编译过后就搭临时 harness 跑本轮 smoke 取证。

● Todo started: inspect-stage3-scope

● Build solution after changes
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 524 lines...

编译已经把一个真实回归点抓出来了：`DesktopUiStatus` 在部分 Infrastructure 文件里缺 `using`。这类问题正好趁现在补掉，再继续 smoke。

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs

我先把编译回归闭环，再进入 smoke harness；这样后面的运行证据才可信。

● Rebuild after using fixes
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 690 lines...

我开始搭“仅用于取证”的临时 harness，放在 session-state 里，不进产品代码也不改现有分层。之后会用它跑 direct CLI smoke 和 seam smoke 两类证据。

● Create temporary stage3 smoke harness
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerDir=Join-Path $root 'seam-runner'; New-Item -ItemType Directory -Force -Path
  $cliDir,$runnerDir | Out-Null; @'
  @echo off...
  └ 144 lines...

我开始跑取证脚本：先拿 direct CLI 正向证据，再拿经过 seam 的 start/repair 证据，并把命令、退出码、日志落点与复跑步骤都写进 session artifact。

✗ Run stage3 smoke evidence script
  $ $ErrorActionPreference='Stop';
  $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\sta
  ge3-smoke';
  $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj';...
  Command not executed. The 'Stop-Process' command must specify at least one process using -Id
  <PID>.

取证脚本在清理阶段挂了一下，是脚本本身的问题，不是产品代码。我先把清理逻辑修稳，再分步拿证据，避免一次长脚本把细节吞掉。

● Check harness commands and existing processes
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $openclawCmd=Join-Path $cliDir 'openclaw.cmd'; $env:PATH="$cliDir;$env:PATH";
  $env:OPENCLAW_HARNESS_TRACE_DIR=Join-Path $root 'debug';
  $env:OPENCLAW_HARNESS_GATEWAY_MODE='success'; Write-Host "VERSION:"; & $openclawCmd --version;...
  └ 10 lines...

● Run direct gateway daemon smoke
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $openclawCmd=Join-Path $cliDir 'openclaw.cmd'; $directDir=Join-Path $root 'direct-success';
  New-Item -ItemType Directory -Force -Path $directDir | Out-Null;
  $env:PATH="$cliDir;$env:PATH"; $env:OPENCLAW_HARNESS_TRACE_DIR=$directDir; ...
  └ 17 lines...

● Read ~\AppData\Local\Temp\copilot-tool-output-1773503328259-lpujn7.txt lines 1-160
  └ 12 lines read

● Run seam success smoke
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-success.json'; $traceDir=Join-Path $root 'seam-success'; New-Item -ItemType Directory
  -Force -Path $traceDir | Out-Null; $env:PATH="$cliDir;$env:PATH"; ...
  └ 12 lines...

seam-runner 报了真实错误，不是 smoke 本身：序列化匿名对象时踩到了模型构造限制。我先读全异常，再改 harness，本体代码不动。

● Read shell output: Waiting up to 10 seconds for command output
  └ 2 lines...

● Read shell output: Waiting up to 10 seconds for command output
  └ 2 lines...

● Stop shell
  └ 1 line...

● Edit ~\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\stage3-smoke\seam-runner\P
  rogram.cs

● Stop any lingering harness gateway processes
  $ $procs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like
  '*openclaw-harness.js*gateway-daemon*' }; foreach ($p in $procs) { if ($p.ProcessId) {
  Stop-Process -Id $p.ProcessId -ErrorAction SilentlyContinue; Write-Host "Stopped $($p.ProcessId)"
  } }
  └ 1 line...

● Run seam success smoke
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-success.json'; $traceDir=Join-Path $root 'seam-success'; New-Item -ItemType Directory
  -Force -Path $traceDir | Out-Null; $env:PATH="$cliDir;$env:PATH"; ...
  └ 12 lines...

我怀疑这不是 harness 问题，而是 local 模式真实运行期的 DI/构造路径问题。先把异常完整拿出来；如果确认是产品代码缺口，我会顺手修掉。

● Capture seam runner runtime failure
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $out=Join-Path $root
  'runner.out.log'; $err=Join-Path $root 'runner.err.log'; $env:PATH="$cliDir;$env:PATH";
  $env:OPENCLAW_WINDOWS_MODE='local'; $env:OPENCLAW_GATEWAY_ENDPOINT='http://127.0.0.1:18789'; ...
  └ 15 lines...

● Read ~\AppData\Local\Temp\copilot-tool-output-1773503694297-swfucm.txt lines 1-180
  └ 30 lines read

我抓到一个真实阻断：`OPENCLAW_WINDOWS_MODE=local` 下，DI 无法构造 `LocalGatewayRuntimeInspector`，这会让阶段3本地接入链路在运行期直接炸掉。我现在把它修掉，再重新取证。

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs

这次顺手修的是运行期事实缺口，不是新需求：如果不把构造器公开，本轮任何 local smoke 都不可信。先重新 build，再跑证据脚本。

● Build after LocalGatewayRuntimeInspector fix
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 507 lines...

我换成更稳的修法：不把内部类型整体公开，而是在 Infrastructure 里用工厂注册 `LocalGatewayRuntimeInspector`。这样既修 runtime，又不破坏分层边界。

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  Edit src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs

● Build after DI registration fix
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 545 lines...

● Run seam success smoke after fix
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-success.json'; $traceDir=Join-Path $root 'seam-success'; New-Item -ItemType Directory
  -Force -Path $traceDir | Out-Null; $env:PATH="$cliDir;$env:PATH"; ...
  └ 17 lines...

● Run seam repair smoke after fix
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-repair.json'; $traceDir=Join-Path $root 'seam-repair'; New-Item -ItemType Directory
  -Force -Path $traceDir | Out-Null; $env:PATH="$cliDir;$env:PATH"; ...
  └ 16 lines...

✗ Read ~\AppData\Roaming\OpenClaw.Windows\settings.json
  Path does not exist

● Read
  ~\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\stage3-smoke\seam-repair.json
  lines 1-220
  └ 87 lines read

● Read
  ~\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\stage3-smoke\seam-success.json
  lines 1-220
  └ 81 lines read

● Read ~\AppData\Local\OpenClaw.Windows\logs\gateway-repair.log lines 1-120
  └ 3 lines read

● Read ~\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\stage3-smoke\direct-succes
  s\openclaw-harness-trace.log lines 1-80
  └ 4 lines read

● Read ~\AppData\Local\OpenClaw.Windows\logs\gateway-daemon.log lines 1-120
  └ 6 lines read

证据已经拿全了：direct CLI、seam start、seam repair、目录存在与日志落点都有事实。最后我把这些整理成一份可复跑文本证据，并做收尾验证。

● Todo started: implement-stage3-fixes

● Write consolidated smoke evidence file
  $ $ErrorActionPreference='Stop';
  $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-49db-b85b-a6e5079be69c\files\sta
  ge3-smoke';
  $evidencePath=Join-Path $root 'stage3-smoke-evidence.txt';
  $success = Get-Content -Path (Join-Path $root 'seam-success.json') -Raw | ConvertFrom-Json;...
  └ 160 lines...

我还想补最后一个体验口子：repair path 的详情里出现了英文超时句子，看起来是 `HttpClient` 原生异常冒出来了。我先看 probe 层，能翻成中文就顺手翻掉。

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs lines 170-220
  └ 51 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs lines 100-115
  └ 16 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProbeClient.cs
  └ 125 lines read

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayProbeClient.cs

我把 probe 层异常摘要翻成中文后，再回归一次 build 和 repair/success smoke，确保最后交付里不再带系统英文超时句。

● Todo started: verify-stage3

● Build after probe localization
  $ dotnet build .\OpenClaw.Windows.sln -v minimal
  └ 566 lines...

● Refresh seam repair smoke JSON
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-repair.json'; $traceDir=Join-Path $root 'seam-repair'; $env:PATH="$cliDir;$env:PATH";
  $env:OPENCLAW_WINDOWS_MODE='local'; $env:OPENCLAW_GATEWAY_ENDPOINT='http://127.0.0.1:18789'; ...
  └ 10 lines...

● Refresh seam success smoke JSON
  $ $ErrorActionPreference='Stop'; $root='C:\Users\kukisama\.copilot\session-state\f2158bf8-cb1b-4
  9db-b85b-a6e5079be69c\files\stage3-smoke'; $cliDir=Join-Path $root 'fake-openclaw';
  $runnerProj=Join-Path $root 'seam-runner\SeamRunner.csproj'; $jsonPath=Join-Path $root
  'seam-success.json'; $traceDir=Join-Path $root 'seam-success'; $env:PATH="$cliDir;$env:PATH";
  $env:OPENCLAW_WINDOWS_MODE='local'; $env:OPENCLAW_GATEWAY_ENDPOINT='http://127.0.0.1:18789'; ...
  └ 8 lines...

并行回归把两个 smoke 用了同一端口，repair 那份结果被 success run 干扰了。我马上串行重跑 repair，保留最终正确证据。

● Stop lingering harness gateway processes
  $ $procs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like
  '*openclaw-harness.js*gateway-daemon*' }; foreach ($p in $procs) { if ($p.ProcessId) {
  Stop-Process -Id $p.ProcessId -ErrorAction SilentlyContinue; Write-Host "Stopped $($p.ProcessId)"
  } }
  └ 1 line...

