先把现状和阻断证据拉平：我会建计划、登记 todo、抽查相关代码与文案，并重新采集本机 `.NET` 环境事实，看看这轮能推进到哪一步。

● Glob "src\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Grep "Live integration|not yet wired|MockDiagnosticsAdapter|LocalDiagnosticsAdapter|Configuration"
 in src\**\*.cs (C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● Create plan and check SDKs
  $ $plan = @'
  # Plan
  1. Verify current .NET environment and capture hard facts for SDK availability.
  2. Inspect current adapter and diagnostics wording relevant to mock/local mode.
  3. Patch stale mock diagnostics wording only, preserving architecture boundaries and 4-page ...
  └ 8 lines...

我已经确认计划已落地，但当前机器的 `dotnet --list-sdks` 没有返回任何 SDK 条目。接着我会直接读目录和相关文件，把需要修的 mock 口径位置找准。

● List directory .
  └ 6 files found

● Read ~\.copilot\session-state\277e1303-5651-4be8-82d8-4311ef2abfa6\plan.md
  └ 6 lines read

● Grep "interface IDiagnosticsAdapter|class MockDiagnosticsAdapter|class
LocalDiagnosticsAdapter|class LocalGatewayAdapter|class LocalGatewayRuntimeInspector"
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 13 lines found

● Grep "MockDiagnosticsAdapter|LocalDiagnosticsAdapter|Live integration|not yet wired|start
orchestration|Mock-only|Deferred" (C:\Users\kukisama\Downloads\Project\longxia)
  └ 5 lines found

我已经定位到需要动的文件，下一步直接读 `MockDiagnosticsAdapter`、`LocalDiagnosticsAdapter` 和相关接口实现，确保只修口径、不碰分层。

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 118 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 12 lines read

`MockDiagnosticsAdapter` 的残留 blocker 已经看到了。我再扫一轮 `Diagnostics / Configuration` 相关文案，避免只修一个点却留下同类错误叙事。

✗ Grep "Live integration|not yet wired|Gateway and CLI contracts|Pending
implementation|Mock-only|Deferred|local mode|attach|health-check|start orchestration"
(C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Glob "**\*.axaml" in C:\Users\kukisama\Downloads\Project\longxia\src
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Glob "**\*Configuration*.cs" in C:\Users\kukisama\Downloads\Project\longxia\src
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Glob "**\*Configuration*.axaml" in C:\Users\kukisama\Downloads\Project\longxia\src
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

我只准备动 `MockDiagnosticsAdapter.cs`，把 mock/local 口径彻底拉齐到“mock 可演示、local 可真实探针、start 仍在 adapter seam”。不扩页，也不碰 ViewModel。

● Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs

代码尾巴已经修掉。现在我补一轮“可核查事实”：确认新文案落地，同时重新采集 `dotnet/node/openclaw/probe` 的机器证据，并看看仓库里有没有现成的阶段材料落点。

● Todo started: mock-wording

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● List docs files
  $ Get-ChildItem -Path 'C:\Users\kukisama\Downloads\Project\longxia\docs' -Recurse -File |
  Select-Object -ExpandProperty FullName
  └ 2 lines...

● Collect machine evidence
  $ $ErrorActionPreference='Continue'; Write-Host '## dotnet --list-sdks'; dotnet --list-sdks;
  Write-Host "`n## dotnet --info"; dotnet --info; Write-Host "`n## where dotnet"; where.exe
  dotnet; Write-Host "`n## where node"; where.exe node; Write-Host "`n## where openclaw";
  where.exe openclaw; Write-Host "`n## probe ready"; try { Invoke-WebRequest -Uri
  'http://127.0.0.1:18789/ready' -UseBasicParsing -TimeoutSec 3 | Select-Object StatusCode, ...
  └ 31 lines...

本机阻断又复现了：只有 runtime、没有 SDK，所以 restore/build/run 这条证据链依然不能在当前环境闭环。我再做最后一轮仓内核查，确认没有别的残留错误口径，并看看 `docs/desktop-baseline.md` 是否需要同步。

● Read docs\desktop-baseline.md lines 1-220
  └ 161 lines read

● Search remaining shell wording
  $ Get-ChildItem -Path 'C:\Users\kukisama\Downloads\Project\longxia\src' -Recurse -File -Include
  *.cs,*.axaml | Select-String -Pattern 'Live integration|not yet wired|Gateway and CLI contracts
  are not yet wired|Mock-only|Deferred|Pending implementation|start orchestration' | ForEach-Object
  { '{0}:{1}:{2}' -f $_.Path, $_.LineNumber, $_.Line.Trim() }
  └ 13 lines...

我发现 `docs/desktop-baseline.md` 还停留在更早口径：写的是“只有 mock / local 还没 attach”。这会和现在的真实 adapter 状态打架，所以我顺手把文档对齐到当前事实。

● Edit docs\desktop-baseline.md

我只剩最后一轮核查：确认仓内不再有那句错误叙事，并把文档片段和机器阻断事实一起收口。

● Todo completed: phase2-evidence

● Read docs\desktop-baseline.md lines 80-155
  └ 76 lines read

● Verify stale wording removed
  $ Get-ChildItem -Path 'C:\Users\kukisama\Downloads\Project\longxia\src','C:\Users\kukisama\Downloa
  ds\Project\longxia\docs' -Recurse -File -Include *.cs,*.axaml,*.md | Select-String -Pattern 'Live
  integration not yet wired|Gateway and CLI contracts are not yet wired' | ForEach-Object {
  '{0}:{1}:{2}' -f $_.Path, $_.LineNumber, $_.Line.Trim() }
  └ 1 line...

STATUS: BLOCKED
SUMMARY:
<<<SUMMARY
本轮已把 mock/local 口径收紧到可验真状态：`MockDiagnosticsAdapter` 不再宣称“Live integration not yet wired”，并补齐了当前机器的真实阻断证据；同时把 `docs/desktop-baseline.md` 更新到“local 已有真实 attach/health probe、start orchestration 仍在 adapter seam”的事实口径。阶段2仍不能报完成，唯一硬阻断仍是：当前机器没有 `.NET 10 SDK`，因此拿不到 restore/build/run 成功硬证据。
SUMMARY>>>

FACTS:
<<<FACTS
- 改动文件：
  - `src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs`
  - `docs\desktop-baseline.md`
- `MockDiagnosticsAdapter.cs` 已改为：
  - `Mock data source active` 明确为“demo mode + local adapter owns real attach/health probes”
  - blocker 从 `Live integration` 改为 `Gateway start orchestration`
  - 推荐动作改为“mock 用于演示；local 用于真实 attach/health；start 仍留在 `IGatewayAdapter` 后”
- `docs\desktop-baseline.md` 已对齐当前实现：
  - 说明 Infrastructure 同时支持 mock/local 切换
  - 明确 local 已做 PATH 探测、`/ready|/readyz` attach/readiness probe、`/healthz|/health` liveness probe
  - 明确尚缺 `gateway-daemon` start/repair orchestration
- 当前机器实测证据：
  - `dotnet --list-sdks`：无输出
  - `dotnet --info`：`Host 10.0.5`，`No SDKs were found.`
  - `where dotnet`：`C:\Program Files\dotnet\dotnet.exe`
  - `where node`：`C:\Program Files\nodejs\node.exe`
  - `where openclaw`：未找到
  - `http://127.0.0.1:18789/ready`：拒连
  - `http://127.0.0.1:18789/healthz`：拒连
- 校验结果：
  - 未发现仓内残留 `Live integration not yet wired` / `Gateway and CLI contracts are not yet wired` 文案
  - 未扩页；仍维持 4 页壳
  - 本轮未把网络/进程/配置逻辑回渗到 ViewModel
- 因主线已明确“未拿到 SDK 成功机证据前不要继续空跑 restore/build/run”，本轮未在 runtime-only 机器上强行执行 `restore/build/run`
FACTS>>>

ADJUSTMENTS:
<<<ADJUSTMENTS
- 顺手把 `docs/desktop-baseline.md` 从阶段1/早期口径更新到当前阶段2事实，避免文档继续误导主线验收。
- 用仓内全文检索复核了残留错误叙事，确认已清干净目标短语。
ADJUSTMENTS>>>

QUESTIONS:
<<<QUESTIONS
- 当前唯一实质阻断是环境：需要一台已安装 `.NET 10 SDK` 的机器，或由主线提供该机器上的 `dotnet --list-sdks` / `restore` / `build` / `run(local)` 日志或截图，我才能把任务卡第 1 条补成“成功硬证据”。
QUESTIONS>>>

NEXT:
<<<NEXT
- 优先在 SDK 机上补齐四条成功证据：`dotnet --list-sdks`、`dotnet restore .\OpenClaw.Windows.sln`、`dotnet build .\OpenClaw.Windows.sln`、`set OPENCLAW_WINDOWS_MODE=local && dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`。
- 一旦 SDK 机跑通，立即整理阶段2最小验收包：可运行事实、终端证据、4 页壳成功/失败/空态证据、以及“当前仍缺 start orchestration”的明确边界。
- 随后进入阶段3首批真实接入点：`openclaw gateway-daemon` 启停编排、诊断页 remediation action、配置页真实 endpoint/CLI 检测回写。
NEXT>>>


Total usage est:        1 Premium request
API time spent:         1m 38s
Total session time:     2m 3s
Total code changes:     +13 -10
Breakdown by AI model:
 gpt-5.4                 311.4k in, 7.2k out, 290.7k cached (Est. 1 Premium request)
