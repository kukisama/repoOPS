先做一次低成本验真：我会核对子线提到的两个改动文件、仓内残留文案、以及接入边界是否还守在 `Infrastructure/Adapter`。

● SQL: Create review todos
  └ 3 row(s) inserted. Last inserted row ID: 3.

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● Read docs\desktop-baseline.md
  └ 164 lines read

● Grep "Live integration not yet wired|Gateway and CLI contracts are not yet wired|Gateway start
orchestration|Mock data source active" in **/* (C:\Users\kukisama\Downloads\Project\longxia)
  └ 5 lines found

我继续抽查边界与机器事实，重点看两件事：一是 `App/ViewModels` 有没有回渗基础设施逻辑，二是当前环境是否确实只有 runtime 没有 SDK。

● Todo started: review-files

● Glob "src\OpenClaw.Windows.App\Views\**\*.axaml" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "src\OpenClaw.Windows.App\ViewModels\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

✗ Grep "ProcessStartInfo|HttpClient|HttpRequestMessage|File\.|Directory\.|WebRequest|Socket|127\.0\.
0\.1|OPENCLAW_WINDOWS_MODE|OPENCLAW_GATEWAY_ENDPOINT" in **/*.cs
(C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.Application)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Grep "ProcessStartInfo|HttpClient|HttpRequestMessage|File\.|Directory\.|WebRequest|Socket|127\.0\.
0\.1|OPENCLAW_WINDOWS_MODE|OPENCLAW_GATEWAY_ENDPOINT" in **/*.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.App)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Check SDK and local probe facts
  $ dotnet --list-sdks; Write-Host '---'; dotnet --info; Write-Host '---'; Get-Command dotnet |
  Select-Object -ExpandProperty Source; Write-Host '---'; Get-Command node -ErrorAction
  SilentlyContinue | Select-Object -ExpandProperty Source; Write-Host '---'; Get-Command
  openclaw -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source; Write-Host
  '---'; try { (Invoke-WebRequest -UseBasicParsing http://127.0.0.1:18789/ready -TimeoutSec ...
  └ 29 lines...

`rg` 在这个仓库被 `.gitignore` 的 Windows 反斜杠写法绊住了，我改用目录视图和 PowerShell 精准抽样，不影响复核结论。

● List directory src\OpenClaw.Windows.App
  └ 10 files found

● List directory src\OpenClaw.Windows.Application
  └ 4 files found

● List directory src\OpenClaw.Windows.Infrastructure
  └ 11 files found

● Inspect app boundary and page hints
  $ $root='C:\Users\kukisama\Downloads\Project\longxia'; Write-Host '--- ViewModels ---';
  Get-ChildItem "$root\src\OpenClaw.Windows.App" -Recurse -File -Include *.cs | Where-Object {
  $_.FullName -match 'ViewModel|Views' } | ForEach-Object { $_.FullName }; Write-Host '---
  Boundary hits in App ---'; Select-String -Path "$root\src\OpenClaw.Windows.App\**\*.cs"
  -Pattern 'HttpClient|ProcessStartInfo|127\.0\.0\.1|OPENCLAW_WINDOWS_MODE|OPENCLAW_GATEWAY_ENDP...
  └ 20 lines...

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 35 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 118 lines read

再补一层口径抽查：我只查和验收直接相关的关键词，确认 UI/诊断叙事现在是否真的统一到了“mock 可演示、local 可 attach/health、start 仍未落地”。

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Search acceptance copy across source and docs
  $ $root='C:\Users\kukisama\Downloads\Project\longxia';
  Write-Host '--- Residual bad copy ---';
  Select-String -Path "$root\src\**\*.cs","$root\docs\**\*.md","$root\src\**\*.axaml" -Pattern
  'Live integration not yet wired|Gateway and CLI contracts are not yet wired' -ErrorAction
  SilentlyContinue | ForEach-Object { "{0}:{1}:{2}" -f $_.Path,$_.LineNumber,$_.Line.Trim() };...
  └ 29 lines...

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● List page shell files
  $ $root='C:\Users\kukisama\Downloads\Project\longxia'; Get-ChildItem
  "$root\src\OpenClaw.Windows.App\Views\Pages" -File | Select-Object -ExpandProperty Name;
  Write-Host '---'; Get-ChildItem "$root\src\OpenClaw.Windows.App\ViewModels\Pages" -File |
  Select-Object -ExpandProperty Name
  └ 14 lines...

我已基本确认边界和文案收口；最后补一眼工程目标框架，确保它仍然是 `.NET 10 + Avalonia`，没有发生技术栈漂移。

● Todo completed: review-boundaries, review-runtime-evidence

● Read OpenClaw.Windows.sln
  └ 33 lines read

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

VERDICT: REVISE
GOAL_STATUS: INCOMPLETE
CONTINUE: YES
NEXT_STAGE: 阶段2：核心工作台成型
NEXT_STAGE_GOAL: 补齐真实 `.NET 10 SDK` 机器上的可运行硬证据，并把 local 模式最小真实接入的运行态证据收成可验收包
NEXT_ROUND_GOAL: 拿到 `restore/build/run` 成功证据，补齐 local 模式真实成功/失败/空态证据，并形成“可运行事实 + start orchestration 仍缺”的阶段2最小验收包

SUMMARY:
<<<SUMMARY
我抽查了代码、文档和本机终端事实，子线这轮“口径收紧”基本属实，可保留但还不能收阶段2。

已验真的部分：
- `src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs` 确实已去掉 `Live integration not yet wired` 叙事，改成“mock 用于演示，local 拥有真实 attach/health probes，start 仍留在 adapter seam”。
- `docs\desktop-baseline.md` 已对齐到当前事实：支持 mock/local 切换；local 已有 PATH 探测、`/ready|/readyz` attach/readiness probe、`/healthz|/health` liveness probe；`gateway-daemon` start/repair orchestration 仍未实现。
- 仓内未检出残留 `Live integration not yet wired` / `Gateway and CLI contracts are not yet wired` 文案。
- 4 页壳仍在：`Overview / Sessions / Configuration / Diagnostics`，未扩页。
- 分层仍守住：`ServiceCollectionExtensions` 只在 Infrastructure 注入 mock/local 适配器；`MainWindowViewModel` 仍只吃 `DesktopWorkbenchStore` 快照；我对 `App` 侧做了关键词抽查，未见 HTTP、进程、文件、环境变量逻辑回渗进 ViewModel。

本机事实也基本坐实了子线阻断说明：
- `dotnet --info` 显示 Host/Runtime 为 `10.0.5`，且 `No SDKs were found`。
- `dotnet` 与 `node` 可找到，`openclaw` 当前找不到。
- `http://127.0.0.1:18789/ready` 与 `/healthz` 当前均拒连。

但任务卡里真正的硬目标仍未完成：
- 还没有一台装有 `.NET 10 SDK` 的机器上的 `dotnet --list-sdks`、`restore`、`build`、`OPENCLAW_WINDOWS_MODE=local` 下 `run` 成功证据。
- 因而阶段2所需的“可运行工作台”硬证据仍缺最后一块，现阶段只能认定为“文案和边界已收口，环境阻断被准确定位”，不能认定为阶段2可验收完成。
SUMMARY>>>

CHANGE_DECISION:
<<<CHANGE_DECISION
正式保留：
- 保留 `MockDiagnosticsAdapter` 口径修正：mock 只承担演示，local 承担真实 attach/health probe，start orchestration 仍在 `IGatewayAdapter` 后。
- 保留 `docs\desktop-baseline.md` 向阶段2事实口径收敛的更新，作为主线验收基线。
- 继续保留 local/mock 切换在 Infrastructure 组合根完成、而非在 ViewModel 中分支的做法。
- 继续保留 4 页壳与当前 `No*` 布尔 + fallback/load/error 组合，不扩页。

下一轮顺手修：
- 在拿到 SDK 机后，把“成功态 / 失败态 / 空态”的真实运行证据补成最小验收包；优先终端证据，必要时再补截图。
- 若 local 真实运行后发现 UI 文案仍有“可启动”与“仅可 attach”边界混淆，统一收紧到“已实现 attach/health，未实现 start/repair orchestration”。

冻结不扩散：
- 不新增页面。
- 不把 start/attach/health-check 逻辑上卷到 ViewModel/Store/MainWindow。
- 不把 local 模式扩写成 C# runtime 重构版。
- 在没拿到 SDK 成功机证据前，不宣称阶段2完成。
CHANGE_DECISION>>>

NEXT_TASK_CARD:
<<<NEXT_TASK_CARD
1. 阻断先清：在装有 `.NET 10 SDK` 的机器上留存并回传 `dotnet --list-sdks`、`dotnet restore .\OpenClaw.Windows.sln`、`dotnet build .\OpenClaw.Windows.sln`、`$env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj` 的成功证据。
2. 运行态收口：基于真实 local 运行结果，补一组最小成功/失败/空态证据，证明 4 页壳文案与诊断结果和真实环境一致。
3. 验收包整理：把阶段2材料收成“可运行事实 + local 已有真实 attach/health probe + start orchestration 仍缺”的最小验收包。
4. 并行预热阶段3：只列首批真实接入点，不开新页，优先 `IGatewayAdapter` 内的 start/repair orchestration、CLI/版本兼容检查、日志路径与常见诊断动作。
NEXT_TASK_CARD>>>

NEXT_REVIEW_FOCUS:
<<<NEXT_REVIEW_FOCUS
1. 是否终于拿到 `.NET 10 SDK` 机器上的 restore/build/run 成功硬证据。
2. local 模式真实运行后，Configuration / Diagnostics / Overview 文案是否完全贴合实际环境，不再把“未实现 start orchestration”说成“未接入 local”。
3. 真实接入是否仍严格停留在 adapter/infrastructure 边界，没有向 ViewModel 回渗。
4. 阶段2是否已具备完整最小验收包：4 页壳、mock/local 可切换、真实 attach/health-check、运行证据、未完项清单。
NEXT_REVIEW_FOCUS>>>


Total usage est:        1 Premium request
API time spent:         1m 21s
Total session time:     1m 46s
Total code changes:     +0 -0
Breakdown by AI model:
 gpt-5.4                 260.8k in, 6.1k out, 236.3k cached (Est. 1 Premium request)
