我先收束现状并建立执行骨架：同步盘点 4 页工作台、模式/诊断真值点、以及本机 `.NET 10 SDK` 验证阻塞，再直接改代码。

● SQL: Initialize task todos
  └ Executed 3 statement(s)

● Glob "src\**\*.{cs,axaml,csproj}" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Grep "LoadState|OPENCLAW_WINDOWS_MODE|OPENCLAW_GATEWAY_ENDPOINT|DiagnosticsAdapter|GatewayAdapter|
OverviewPage|SessionsPage|ConfigurationPage|DiagnosticsPage|MainWindowViewModel|ResolvedWorkbenchMod
e|health|probe" (C:\Users\kukisama\Downloads\Project\longxia)
  └ 5 lines found

● Create session plan file
  $ $plan = @'
  # Plan
  1. Audit existing desktop workbench pages, viewmodels, and infrastructure truth sources.
  2. Implement stage-2 workbench refinements within current 4-page shell only.
  3. Verify restore/build/run on current machine; if blocked, capture exact prerequisites and ...
  └ 6 lines...

我已经拿到大范围命中，接下来缩到关键文件直接读，避免在无关结果里打转。

● List directory src
  └ 3 files found

✗ Grep
"LoadState|GatewayEndpoint|ModeSource|ModeSummary|Empty|Error|Log|Diagnostic|Attach|Start|Health" in
 *.{cs,axaml} (C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Grep "class MainWindowViewModel|record ResolvedWorkbenchMode|interface IGatewayAdapter|interface
IDiagnosticsAdapter|class MockGatewayAdapter|class LocalGatewayAdapter|class
MockDiagnosticsAdapter|class LocalDiagnosticsAdapter|class DesktopWorkbenchService|class
ServiceCollectionExtensions" (C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Collect dotnet verification evidence
  $ dotnet --info; Write-Host '---'; dotnet restore .\OpenClaw.Windows.sln; Write-Host '---'; dotnet
   build .\OpenClaw.Windows.sln; Write-Host '---'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 39 lines...

● Stop shell
  └ 1 line...

● List directory src\OpenClaw.Windows.Application
  └ 4 files found

● List directory src\OpenClaw.Windows.Infrastructure
  └ 9 files found

● List directory src\OpenClaw.Windows.App
  └ 10 files found

我确认了三层项目结构和本机 SDK 阻断；现在开始对关键 ViewModel、页面和基础设施做点对点收口。

● List directory src\OpenClaw.Windows.App\ViewModels
  └ 4 files found

● List directory src\OpenClaw.Windows.Application\Abstractions
  └ 4 files found

● List directory src\OpenClaw.Windows.Application\Models
  └ 1 file found

● List directory src\OpenClaw.Windows.App\Views
  └ 1 file found

● List directory src\OpenClaw.Windows.Application\State
  └ 1 file found

● List directory src\OpenClaw.Windows.Infrastructure\Mock
  └ 3 files found

● Read src\OpenClaw.Windows.App\ViewLocator.cs
  └ 44 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 63 lines read

● List directory src\OpenClaw.Windows.App\Views\Pages
  └ 8 files found

● List directory src\OpenClaw.Windows.App\ViewModels\Pages
  └ 4 files found

● Read src\OpenClaw.Windows.App\App.axaml
  └ 17 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  └ 16 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 130 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  └ 25 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 16 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 19 lines read

● Read src\OpenClaw.Windows.App\ViewModels\NavigationItemViewModel.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 55 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 58 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 73 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 84 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 10 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  └ 12 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IConfigurationStore.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDesktopWorkbenchService.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.Infrastructure\ResolvedWorkbenchMode.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  └ 38 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 124 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 28 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 108 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 34 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 55 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 54 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 29 lines read

我已经定位到三类问题：`LoadState` 写死、endpoint/SDK 诊断不真、以及 4 页还缺少“主流程级”的状态/空态/诊断入口。下面直接补。

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

● Read OpenClaw.Windows.sln
  └ 33 lines read

● Read src\OpenClaw.Windows.App\Styles\Theme.axaml
  └ 66 lines read

● Read src\OpenClaw.Windows.App\Styles\Tokens.axaml
  └ 14 lines read

● Read src\OpenClaw.Windows.App\ViewModels\ViewModelBase.cs
  └ 26 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 13 lines read

● Read src\OpenClaw.Windows.Application\OpenClaw.Windows.Application.csproj
  └ 7 lines read

● Edit src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  Edit src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  Create src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.App\ViewModels\NavigationItemViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\MainWindow.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml

我补完主干实现后做了一轮静态自检，发现还有几处会影响落地的细小编译/绑定风险，马上一起收掉。

✗ Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\MainWindow.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  Failed to apply patch: Error: Failed to find expected lines in C:\Users\kukisama\Downloads\Project
  \longxia\src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs:
                  OnPropertyChanged(nameof(CurrentPage));
                  OnPropertyChanged(nameof(HasCurrentPage));
                  OnPropertyChanged(nameof(CurrentSectionTitle));
                  OnPropertyChanged(nameof(CurrentSectionDescription));
                  OnPropertyChanged(nameof(CurrentSectionStatus));
              }
          }

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 165 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  └ 24 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 33 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 35 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 86 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● Edit src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\MainWindow.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml

代码已改完，最后做一轮事实化校验：扫掉残余绑定问题，并补充一个不用 SDK 也能成立的本机阻断证据。

● Todo started: stage2-audit

✗ Grep "!Has" (C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Grep "GetGatewayControlActionsAsync|GetDiagnosticEntryPointsAsync|DotNetSdkProbe|NoCurrentPage|NoF
irstReleaseFlows|NoSessions|NoAdapterBoundaries|NoGatewayControls|NoReadinessProbes|NoDiagnostics|No
DiagnosticEntryPoints|NoBlockingItems" (C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Capture SDK folder and dotnet info evidence
  $ Write-Host 'dotnet-sdk-folder:'; if (Test-Path 'C:\Program Files\dotnet\sdk') { Get-ChildItem
  'C:\Program Files\dotnet\sdk' -Name } else { Write-Host '<missing>' }; Write-Host '---';
  Write-Host 'dotnet-root-env:'; $env:DOTNET_ROOT; Write-Host '---'; dotnet --info
  └ 21 lines...

`rg` 在这个仓库会被 `.gitignore` 的反斜杠写法绊住，我改用 PowerShell 做最终定点核查，不继续浪费回合。

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 138 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 97 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 92 lines read

● Search edited symbols via PowerShell
  $ $root = 'C:\Users\kukisama\Downloads\Project\longxia\src'; Write-Host 'bang-bindings:';
  Get-ChildItem $root -Recurse -Include *.axaml,*.cs | Select-String -Pattern '!Has|!No' |
  ForEach-Object { $_.Path + ':' + $_.LineNumber + ': ' + $_.Line.Trim() }; Write-Host '---';
  Write-Host 'gateway-control-contract:'; Get-ChildItem $root -Recurse -Include *.cs |
  Select-String -Pattern 'GetGatewayControlActionsAsync|GetDiagnosticEntryPointsAsync|DotNetSdkP...
  └ 52 lines...

我已经把可核查的代码和环境证据都收齐了；最后更新任务状态，然后按主线模板交付。

● Todo completed: stage2-implement, stage2-verify

● Count source files for final audit
  $ Get-ChildItem -Path '.\src' -Recurse -File | Where-Object { $_.Extension -in '.cs','.axaml' } |
  Measure-Object | ForEach-Object { "source-files-scanned=$($_.Count)" }
  └ 2 lines...

STATUS: PARTIAL
SUMMARY:
<<<SUMMARY
本轮把现有 4 页收束成了更像“可用工作台”的形态：补了导航状态、空态/无页态、模式切换可见性，以及最小日志/诊断入口；同时把 `LoadState`、gateway endpoint、`.NET SDK` 诊断改成按当前模式/机器环境真实反映。另在 `IGatewayAdapter` 边界内补了 start/attach/health-check 的最小设计口，但没有越线去做 Node/TS 内核重写。

阶段1遗留验证未能补成“成功运行硬证据”：本机仍只有 `.NET 10.0.5 runtime`、没有 SDK，因此 `restore/build/run` 依旧无法成功，只能提交阻断归因和最短复验路径。
SUMMARY>>>
FACTS:
<<<FACTS
1. 工作台主流程收口已落代码：
- `src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs`
- `src\OpenClaw.Windows.App\MainWindow.axaml`
- `src\OpenClaw.Windows.App\ViewModels\NavigationItemViewModel.cs`
改动点：导航项新增状态文案；左侧增加“当前 section 状态”卡；右侧增加无页 fallback；`LoadState` 不再写死 mock，而是按 `DesktopWorkbenchSnapshot` 真实生成。

2. 4 页内收口而未增页：
- `Views\Pages\SessionsPage.axaml` + `ViewModels\Pages\SessionsPageViewModel.cs`
- `Views\Pages\ConfigurationPage.axaml` + `ViewModels\Pages\ConfigurationPageViewModel.cs`
- `Views\Pages\DiagnosticsPage.axaml` + `ViewModels\Pages\DiagnosticsPageViewModel.cs`
改动点：补了空态；Configuration 页补“模式可见性 + 切换提示”；Diagnostics 页补“Gateway control readiness”和“Logs and diagnostic entry points”。

3. 真实值问题已修：
- `src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs` 现在注入 `ResolvedWorkbenchMode`，gateway endpoint probe 改为复用真实解析出的 `_mode.GatewayEndpoint`。
- `src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs`
- `src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs`
- `src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs`（新增）
改动点：`.NET toolchain` 诊断改为探测标准 `dotnet\sdk` 目录，而不是静态写死 “SDK missing”。

4. adapter 边界增强已落地且仍留在 Infrastructure/Application：
- `src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs`
- `src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs`
- `src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs`
- `src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs`
- `src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs`
新增合同：
- `GetGatewayControlActionsAsync()`：承载 start / attach / health-check 设计口
- `GetDiagnosticEntryPointsAsync()`：承载最小日志/诊断入口
新增模型：
- `GatewayControlAction`
- `DiagnosticEntryPoint`

5. 本机环境阻断有新证据，不再反复空跑：
- `dotnet --info` 输出：`No SDKs were found.`
- `C:\Program Files\dotnet\sdk`：`<missing>`
- `DOTNET_ROOT`：未设置
此前已复跑过：
- `dotnet restore .\OpenClaw.Windows.sln`
- `dotnet build .\OpenClaw.Windows.sln`
- `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
均因缺少 SDK 失败；本轮未再重复无效尝试。

6. 最短复验路径：
- 安装 `.NET 10 SDK`
- 运行：
  - `dotnet --list-sdks`
  - `dotnet restore .\OpenClaw.Windows.sln`
  - `dotnet build .\OpenClaw.Windows.sln`
  - `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`

7. 最终任务跟踪：
- `stage2-audit = done`
- `stage2-implement = done`
- `stage2-verify = done`
FACTS>>>
ADJUSTMENTS:
<<<ADJUSTMENTS
1. 顺手把 Diagnostics 页里的“日志/诊断入口”做成统一模型，而不是散落在静态文案里，便于后续接真实日志路径时只改 adapter。
2. 顺手给 Sessions / Configuration / Diagnostics / MainWindow 都补了 `No*` 布尔属性，避免直接在 Avalonia 绑定里写取反表达式，降低 XAML 绑定风险。
3. 顺手把 `IGatewayAdapter` 的职责文案从“later start/attach”提升为明确包含“start/attach/health-check contract”，让 Phase 2 接真实 Gateway 时边界更清楚。
ADJUSTMENTS>>>
QUESTIONS:
<<<QUESTIONS
1. 当前仓库里的 `rg` 会被根目录 `.gitignore` 中的 Windows 反斜杠规则（如 `bin\`）绊住，导致工具搜索经常报 `dangling '\'`。这不影响应用代码本身，但会影响后续自动化检索效率。是否允许下一轮把 `.gitignore` 规范化为兼容 `rg` 的写法？
2. 任务卡要求“在装有 .NET 10 SDK 的机器上补 restore/build/run 成功证据”。当前执行环境明确不满足该前置条件，所以本轮只能给阻断归因与复验路径，无法伪造成功证据。主线若必须拿到该证据，需要切换到具备 SDK 的机器或提供新的执行环境。
QUESTIONS>>>
NEXT:
<<<NEXT
1. 在具备 `.NET 10 SDK` 的机器上补齐 `restore/build/run` 成功硬证据，并截图/保留终端输出。
2. 按本轮新加的 `GetGatewayControlActionsAsync()` 设计口，在 `LocalGatewayAdapter` 内最小实现真实 attach/health-check，先不做复杂进程编排。
3. 把 Diagnostics 页的“Future desktop log path”接到真实本地日志落点或统一日志服务，形成可实际排障的入口。
NEXT>>>


Total usage est:        1 Premium request
API time spent:         4m 27s
Total session time:     5m 21s
Total code changes:     +476 -50
Breakdown by AI model:
 gpt-5.4                 798.2k in, 24.3k out, 749.2k cached (Est. 1 Premium request)
