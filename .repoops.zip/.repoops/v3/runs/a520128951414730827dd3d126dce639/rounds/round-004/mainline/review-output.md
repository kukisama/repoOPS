先做一轮低成本验真：我会核对子线提到的关键文件、文案清理和本机环境证据，再据此给出是否接收与下一轮任务卡。

● SQL: Create review todos
  └ Executed 3 statement(s)

● Grep "Phase 1|Phase 2|Loading mock workbench snapshot" in src\**\*.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● Glob "src\**\*.{cs,axaml}" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Create plan and verify local env
  $ @'
  # Round 4 review plan
  - Verify local environment evidence for .NET 10 SDK, node/openclaw commands, and gateway probe
   endpoints.
  - Inspect claimed files for local attach/health-check wiring and UI boundary integrity....
  └ 38 lines...

我已经确认了最关键的本机阻断：这里只有 `.NET 10` runtime，没有 SDK，所以本轮不可能补出 `restore/build/run` 成功证据。接下来我只核对代码是否真的把 local 接入和状态收口到了 adapter 边界。

● Grep "class LocalGatewayRuntimeInspector|class LocalGatewayAdapter|class
LocalDiagnosticsAdapter|class MainWindowViewModel|class ConfigurationPageViewModel|Loading the
workbench snapshot|Mock-only|Deferred|/readyz|/healthz" in src\**\*.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● Grep "IGatewayAdapter|IDiagnosticsAdapter|GetGatewayControlActionsAsync|GetDiagnosticEntryPointsAs
ync|GetGatewayStatusAsync|GetReadinessProbesAsync|GetRecentSessionsAsync" in src\**\*.cs
(C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● List directory src
  └ 3 files found

● List directory src\OpenClaw.Windows.Application
  └ 4 files found

● List directory src\OpenClaw.Windows.App
  └ 10 files found

● List directory src\OpenClaw.Windows.Infrastructure
  └ 11 files found

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 118 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 28 lines read

✗ Read src\OpenClaw.Windows.Application\DesktopWorkbenchService.cs
  Path does not exist

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 12 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  └ 14 lines read

代码层面看，`attach/health-check` 确实已经落在 `Infrastructure`，`ViewModel` 仍是被动消费快照，这一条基本成立。我再补一层上游协议验真和诊断页/Mock 文案抽查，确认不是“本地自说自话”。

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 86 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Search code: repo:openclaw/openclaw "/readyz" OR "/healthz" OR "/ready" OR "/health"
  └ Output too large to read at once (29.9 KB). Saved to: C:\Users\kukisama\AppDa...

抽查结果有一个小偏差：`MockDiagnosticsAdapter` 里仍保留了 `Live integration` 阻塞项，这和“已具备 local 最小真实探针”不完全一致，属于可顺手修的口径尾巴，不是结构性问题。再看一眼上游搜索结果和主界面导航页数，就可以下结论了。

● Todo started: collect-evidence

● Read ~\AppData\Local\Temp\1773498507579-copilot-tool-output-yndnql.txt lines 1-120
  └ 1 line read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 83 lines read

● Todo completed: assess-stage

VERDICT: ACCEPT
GOAL_STATUS: INCOMPLETE
CONTINUE: YES
NEXT_STAGE: 阶段2：核心工作台成型
NEXT_STAGE_GOAL: 补齐桌面工作台在真实 `.NET 10 SDK` 环境上的可运行硬证据，并把 local 模式最小真实接入的口径与诊断闭环收紧到可验收状态
NEXT_ROUND_GOAL: 拿到一台装有 `.NET 10 SDK` 的机器上的 `list-sdks/restore/build/run` 成功证据，同时收掉 mock 诊断口径尾巴，完成阶段2收口
SUMMARY:
<<<SUMMARY
本轮结果我判定“可接收，但不能报阶段完成”。验真后，子线声称的核心改动大体成立：`LocalGatewayRuntimeInspector.cs` 确实新增了 PATH 探测、`/ready|/readyz` 与 `/healthz|/health` 探针，并带 5 秒缓存；`LocalGatewayAdapter.cs` 的 `GetGatewayStatusAsync`、`GetReadinessProbesAsync`、`GetGatewayControlActionsAsync`、`GetRecentSessionsAsync` 已真实消费探针结果；`LocalDiagnosticsAdapter.cs` 也已把 attach/health/prereq/.NET toolchain 接进诊断与 blocker 生成。`MainWindowViewModel.cs` 的初始 `LoadState` 已改为中性文案，`MainWindow.axaml` 仍维持 4 页壳，未扩页；`IGatewayAdapter` / `IDiagnosticsAdapter` 合同仍是边界中心，ViewModel 只吃快照，没有把网络、进程或配置逻辑卷回 UI 层。

环境侧也核到了真实阻断证据：本机 `dotnet --info` 显示只有 `10.0.5` runtime，`No SDKs were found.`；`node.exe` 在 PATH 上，但 `openclaw` 不在 PATH；`http://127.0.0.1:18789/ready` 和 `/healthz` 实测拒连。这与 local 诊断页当前表达基本一致，说明这次不是“说明卡冒充真实接入”，而是已经能反映当前机器真实 attach/health 失败路径。上游协议对齐也有依据：已查到 `openclaw/openclaw` 的 `src/gateway/server-http.ts` 与 `src/gateway/control-ui-routing.ts`，说明 `/ready`、`/readyz`、`/health`、`/healthz` 这类探针路线不是桌面侧自创。

还缺的点也很明确：任务卡第 1 条的“`.NET 10 SDK` 机器上的 restore/build/run 成功硬证据”本轮仍未拿到，所以阶段2不能报 DONE；另外子线摘要说 mock 口径已全面收紧，但我抽查到 `MockDiagnosticsAdapter.cs` 里仍保留 `Live integration` blocker，文案是“Gateway and CLI contracts are not yet wired into C# adapters.”——这在 local 最小真实探针已落地后已不准确，属于非阻断但应下一轮顺手修掉的尾巴。整体上，这一轮解决了“有没有真实 local attach/health-check”这个阶段2关键价值问题，因此我给 ACCEPT；但阶段收口仍卡在 SDK 成功机证据。
SUMMARY>>>
CHANGE_DECISION:
<<<CHANGE_DECISION
正式保留：
- 保留 `LocalGatewayRuntimeInspector` 的 5 秒短缓存；这是低成本降噪，不改变边界，且能避免一次快照内重复超时/拒连。
- 保留 local 模式下 `attach + health-check` 走 `Infrastructure/Adapter` 的做法；这是阶段2到阶段3的正确接入基线。
- 保留 `MainWindow` 4 页壳、不扩页，以及 `No*` 布尔属性 + fallback/load/error 组合。
- 保留 mock 状态从 `Planned` 收紧为 `Mock-only` / `Deferred` 的方向，这能降低 UI 误导。

下一轮顺手修：
- 修 `MockDiagnosticsAdapter` 中残留的 `Live integration` blocker 文案；local 最小真实探针已存在，mock 模式不应继续宣称“Gateway/CLI 合同尚未接入”。
- 继续检查 mock/local 两套文案是否对“已实现真实探针、未实现 start orchestration”表达完全一致，尤其是 Diagnostics / Configuration 两页。

冻结不扩散：
- 不新增页面。
- 不把 start/attach/health-check 上卷进 ViewModel、Store、MainWindow。
- 不把 local 模式扩写成 C# runtime 重构。
- 不在未拿到 SDK 成功机证据前继续空跑 restore/build/run。
CHANGE_DECISION>>>
NEXT_TASK_CARD:
<<<NEXT_TASK_CARD
1. 阻断先收口：在一台装有 `.NET 10 SDK` 的机器上补齐并留存 `dotnet --list-sdks`、`dotnet restore .\OpenClaw.Windows.sln`、`dotnet build .\OpenClaw.Windows.sln`、`set OPENCLAW_WINDOWS_MODE=local && dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj` 成功证据。
2. 顺手修口径尾巴：改掉 `MockDiagnosticsAdapter` 残留的 “Live integration not yet wired” 叙事，严格对齐“mock 可演示、local 已有真实 attach/health probe、start 仍在 adapter seam”。
3. 维持 4 页壳不扩页：只补真实运行后的成功态/失败态/空态截图或终端证据，不做新页面。
4. 若 SDK 机可跑通，则把阶段2收口材料整理为“可运行事实 + 当前仍缺 start orchestration”的最小验收包，并开始为阶段3列首批真实接入点。
NEXT_TASK_CARD>>>
NEXT_REVIEW_FOCUS:
<<<NEXT_REVIEW_FOCUS
1. 下一轮是否终于拿到 `.NET 10 SDK` 机器上的 restore/build/run 成功硬证据。
2. local 模式运行时，UI 文案与诊断结果是否和真实环境完全一致，不再有 mock/未接入的错误叙事。
3. 真实接入是否仍严格停留在 adapter/infrastructure 边界，没有向 ViewModel 回渗。
4. 阶段2是否已经具备“可运行工作台 + mock/local 可切换 + 真实 attach/health-check + 诊断回路”的完整验收包。
NEXT_REVIEW_FOCUS>>>


Total usage est:        1 Premium request
API time spent:         1m 19s
Total session time:     1m 37s
Total code changes:     +0 -0
Breakdown by AI model:
 gpt-5.4                 301.5k in, 5.5k out, 270.2k cached (Est. 1 Premium request)
