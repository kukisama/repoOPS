我先把计划、任务跟代码现场一起拉齐，然后直接修装配和适配边界，再尝试拿构建运行证据。

● SQL: Create stage todos
  └ 5 row(s) inserted. Last inserted row ID: 5.

● List directory .
  └ 6 files found

● List directory docs
  └ 1 file found

✗ Glob "**/*" in C:\Users\kukisama\Downloads\Project\longxia\src
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

我已确认仓库不是空壳，接下来直接读关键文件并补出会话计划，优先锁定 `ViewLocator`、导航壳和 adapter/store 接线点。

● Todo started: plan-stage1

● Glob "src\**\*.{cs,axaml,csproj}" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

✗ Grep "class ViewLocator|DataTemplates|Navigation|DesktopWorkbench|IGatewayAdapter|IDiagnosticsAdap
ter|IConfigurationStore|Mode|readiness|probe" in *.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Create session plan
  $ @'
  # Stage 1 execution plan

  1. Inspect shell wiring, view registration, and current adapter/store boundaries.
  2. Fix page rendering so the four navigated pages resolve explicitly and reliably....
  └ 7 lines...

● List directory src
  └ 3 files found

● List directory src\OpenClaw.Windows.App
  └ 10 files found

● List directory src\OpenClaw.Windows.Infrastructure
  └ 2 files found

● List directory src\OpenClaw.Windows.Application
  └ 4 files found

● List directory src\OpenClaw.Windows.App\Views
  └ 1 file found

● List directory src\OpenClaw.Windows.App\ViewModels
  └ 4 files found

● List directory src\OpenClaw.Windows.Application\Models
  └ 1 file found

● List directory src\OpenClaw.Windows.Application\State
  └ 1 file found

● List directory src\OpenClaw.Windows.Infrastructure\Mock
  └ 4 files found

● List directory src\OpenClaw.Windows.Application\Abstractions
  └ 4 files found

● Read src\OpenClaw.Windows.App\ViewLocator.cs
  └ 41 lines read

● Read src\OpenClaw.Windows.App\App.axaml
  └ 17 lines read

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 44 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml
  └ 63 lines read

● Read src\OpenClaw.Windows.App\MainWindow.axaml.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 130 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  └ 25 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  └ 16 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 16 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 16 lines read

● List directory src\OpenClaw.Windows.App\Views\Pages
  └ 8 files found

● List directory src\OpenClaw.Windows.App\Views\Pages
  └ 8 files found

已经定位到主线提的高概率缺口：`ViewLocator` 确实把 `OverviewPageViewModel` 解析成 `OverviewPageView`，而实际页面类是 `OverviewPage` 一类。接下来我直接把页面解析改成显式注册，并同时补 adapter 模式切换与 readiness 入口。

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml.cs
  └ 17 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  └ 10 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDesktopWorkbenchService.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDesktopWorkbenchService.cs
  └ 122 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 30 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 69 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 19 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 36 lines read

✗ Read src\OpenClaw.Windows.Application\Models\DesktopConfig.cs
  Path does not exist

✗ Read src\OpenClaw.Windows.Application\Models\DiagnosticSignal.cs
  Path does not exist

✗ Read src\OpenClaw.Windows.Application\Models\GatewayStatus.cs
  Path does not exist

✗ Read src\OpenClaw.Windows.Application\Models\BlockingItem.cs
  Path does not exist

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 52 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 53 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 55 lines read

● Read src\OpenClaw.Windows.Application\OpenClaw.Windows.Application.csproj
  └ 7 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 10 lines read

● Check dotnet SDK state
  $ dotnet --info
  └ 15 lines...

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 10 lines read

● Read OpenClaw.Windows.sln
  └ 33 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IConfigurationStore.cs
  └ 8 lines read

● Read docs\desktop-baseline.md
  └ 140 lines read

定位和设计都够了，我开始一次性落代码：显式页面注册、模式解析/DI 装配、本地 readiness probe、以及对应 UI 展示。

● Edit src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  Edit src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  Edit src\OpenClaw.Windows.App\ViewLocator.cs
  Edit src\OpenClaw.Windows.App\App.axaml.cs
  Edit src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  Delete src\OpenClaw.Windows.Infrastructure\Mock\MockDesktopWorkbenchService.cs
  Create src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  Create src\OpenClaw.Windows.Infrastructure\ResolvedWorkbenchMode.cs
  Create src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  Create src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  Edit docs\desktop-baseline.md

代码已经改完一轮，我在做可编译性自检和阻断验证：重点看 XAML/DI/新模型串联有没有断点，然后补 `restore/build/run` 的环境证据。

● Todo started: inspect-baseline

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 124 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 34 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 108 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 73 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 55 lines read

● Read src\OpenClaw.Windows.App\ViewLocator.cs
  └ 44 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 84 lines read

现在补硬证据：我会直接跑 `restore/build/run`，同时扫一遍旧类名残留，确认这轮改动没有把装配线留半截。

● Search for stale shell wiring
  $ Get-ChildItem -Path '.\src' -Recurse -Include *.cs,*.axaml,*.csproj | Select-String -Pattern
  'MockDesktopWorkbenchService|Replace\("ViewModel", "View"|Type.GetType\(name\)' | ForEach-Object {
   "{0}:{1}: {2}" -f $_.Path, $_.LineNumber, $_.Line.Trim() }
  └ 1 line...

● Probe local PATH prerequisites
  $ $node = Get-Command node -ErrorAction SilentlyContinue; $openclaw = Get-Command openclaw
  -ErrorAction SilentlyContinue; [pscustomobject]@{ Node = if ($node) { $node.Source } else {
  '<missing>' }; OpenClaw = if ($openclaw) { $openclaw.Source } else { '<missing>' } } | Format-List
  └ 3 lines...

● Run restore build run validation
  $ $commands = @(
    'dotnet restore .\OpenClaw.Windows.sln',
    'dotnet build .\OpenClaw.Windows.sln',
    'dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj'
  )...
  └ 37 lines...

我发现一个纯文本层面的编译风险：`MockConfigurationStore` 引用了新的 `ResolvedWorkbenchMode`，但命名空间还没引入。我先补这个，再做一次残留扫描与结果收口。

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 28 lines read

● Read shell output: Waiting up to 1 second for command output
  └ 30 lines...

● Scan new symbol usages
  $ Get-ChildItem -Path '.\src' -Recurse -Include *.cs | Select-String -Pattern
  'ResolvedWorkbenchMode|GetReadinessProbesAsync\(|new DesktopConfig\(|new
  DesktopWorkbenchSnapshot\(' | ForEach-Object { "{0}:{1}: {2}" -f $_.Path, $_.LineNumber,
  $_.Line.Trim() }
  └ 20 lines...

● Edit src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs

最后做一遍收口：确认修补后的文件状态、清理长挂的 shell，然后把 todo 状态和可复验命令整理好。

● Stop shell
  └ 1 line...

● Todo completed: fix-shell-wiring, add-mode-probe, validate-dotnet

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockConfigurationStore.cs
  └ 29 lines read

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

STATUS: PARTIAL
SUMMARY:
<<<SUMMARY
本轮把阶段1还差的“壳装配一致性 + adapter 边界铺路”补上了：4 个导航页已改为显式注册装配，不再依赖错误命名映射；同时在 `Infrastructure` 内补了最小 `mock/local` 模式切换与 readiness probe 入口。`restore/build/run` 已实际执行，但当前机器缺少 `.NET 10 SDK`，因此验证证据只能提交为明确环境阻断，不能提交成功构建截图级结果。
SUMMARY>>>
FACTS:
<<<FACTS
改动文件可核查：
- `src\OpenClaw.Windows.App\ViewLocator.cs`：改为 `Overview/Sessions/Configuration/Diagnostics` 四个 ViewModel 到页面类的显式字典映射，并在生成控件时手动赋 `DataContext`。
- `src\OpenClaw.Windows.App\App.axaml.cs`：DI 装配改为 `services.AddDesktopWorkbenchInfrastructure()`，不再把 mock 绑定硬编码在 App 里。
- `src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml`：新增模式来源、readiness probe 入口展示。
- `src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml` 与 `ViewModels\Pages\DiagnosticsPageViewModel.cs`：新增 readiness probes 展示链路。
- `src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs`：新增 `DesktopConnectionMode`、`ReadinessProbe`，并把 `DesktopConfig`/`DesktopWorkbenchSnapshot` 扩成可承载模式与探针信息。
- `src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs`：新增 `GetReadinessProbesAsync()`。
- `src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs`：替换原 `MockDesktopWorkbenchService`，统一组合 snapshot。
- 新增 `src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs`、`ResolvedWorkbenchMode.cs`、`ServiceCollectionExtensions.cs`、`LocalGatewayAdapter.cs`、`LocalConfigurationStore.cs`、`LocalDiagnosticsAdapter.cs`。
- 更新 `src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs`、`MockConfigurationStore.cs`、`MockDiagnosticsAdapter.cs`。
- 更新 `src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj`：补 `Microsoft.Extensions.DependencyInjection` 引用。
- 更新 `docs\desktop-baseline.md`：补 `OPENCLAW_WINDOWS_MODE` / `OPENCLAW_GATEWAY_ENDPOINT` 说明和最短复验命令。

装配一致性事实：
- 之前的 `ViewLocator` 会把 `OverviewPageViewModel` 解析成不存在的 `OverviewPageView`；现已移除这一路径依赖。
- 旧的字符串映射残留已扫过，未再发现 `Replace("ViewModel", "View")` / `Type.GetType(name)` 这类装配逻辑。

模式切换与 probe 事实：
- 模式入口：`OPENCLAW_WINDOWS_MODE`，支持 `local`；未设置或非法值回落到 `mock`。
- endpoint 入口：`OPENCLAW_GATEWAY_ENDPOINT`，未设置默认 `http://127.0.0.1:18789`。
- `local` 模式当前仅做 PATH 级 readiness 探测，不越界到 ViewModel：
  - Node PATH 探测
  - `openclaw` CLI PATH 探测
  - gateway endpoint handoff 展示
- 当前机器 PATH 探测结果：
  - `node` 存在：`C:\Program Files\nodejs\node.exe`
  - `openclaw` 缺失：`<missing>`

构建/运行验证事实：
- `dotnet --info` 已执行，结果显示仅有 runtime `10.0.5`，`No SDKs were found.`
- 已实际执行：
  - `dotnet restore .\OpenClaw.Windows.sln`
  - `dotnet build .\OpenClaw.Windows.sln`
  - `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
- 三条命令均失败，核心报错一致：`No .NET SDKs were found.`
- 三条命令退出码均为 `-2147450725`。
- 这说明当前阻断属于环境/toolchain，不是“未尝试验证”。

最短复验路径：
- 安装 `.NET 10 SDK`
- 运行：
  - `dotnet restore .\OpenClaw.Windows.sln`
  - `dotnet build .\OpenClaw.Windows.sln`
  - `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
- 如需验证 local 模式：
  - `$env:OPENCLAW_WINDOWS_MODE="local"`
  - `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`
FACTS>>>
ADJUSTMENTS:
<<<ADJUSTMENTS
1. 顺手把原本仅 mock 语义的 `MockDesktopWorkbenchService` 收敛成通用 `DesktopWorkbenchService`，避免 local 模式继续挂在误导性类名上。
2. 顺手让 `MockConfigurationStore` 也读取已解析的 endpoint，而不是写死地址，减少后续 mock/local 展示分叉。
3. 顺手在文档里补了模式切换和 local 复验命令，方便主线直接验真。
ADJUSTMENTS>>>
QUESTIONS:
<<<QUESTIONS
无
QUESTIONS>>>
NEXT:
<<<NEXT
优先在有 `.NET 10 SDK` 的机器上拿到真正的 `restore/build/run` 成功证据；若通过，再进入阶段2时可直接把 `LocalGatewayAdapter` 的 PATH/endpoint probe 升级为真实 `openclaw` / `gateway-daemon` attach-start 检查，而无需再改 UI 或 ViewModel 分层。
NEXT>>>


Total usage est:        1 Premium request
API time spent:         4m 9s
Total session time:     5m 0s
Total code changes:     +536 -154
Breakdown by AI model:
 gpt-5.4                 662.4k in, 21.8k out, 630.0k cached (Est. 1 Premium request)
