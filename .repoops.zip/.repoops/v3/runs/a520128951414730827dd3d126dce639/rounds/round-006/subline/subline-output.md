先把仓内现状、任务证据位和可改动面拉齐；如果当前机器仍缺 `.NET 10 SDK`，我会先把可核查增量做满，再明确阻断与替代证据。

✗ Todo added: Collect baseline evidence

● Read OpenClaw.Windows.sln
  └ 33 lines read

● Glob "src\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "docs\**\*" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Create session plan
  $ $plan = @'
  # Plan
  1. Inspect current desktop workbench code, docs, and local/mock adapter boundaries.
  2. Capture machine evidence for dotnet SDK, restore/build/run, and determine whether the
  hard-proof blocker is cleared....
  └ 7 lines...

我先补看目录和关键文件；如果 SDK 仍缺，我会把“不可完成的硬证据”为何缺、仓内还能补到哪一步，一次性收紧。

● SQL: Seed work todos
  └ 4 row(s) inserted. Last inserted row ID: 4.

● List directory .
  └ 6 files found

✗ Glob "**/*" in C:\Users\kukisama\Downloads\Project\longxia\docs
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Glob "**/*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ 33 files found

● Todo started: collect-baseline

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 35 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 118 lines read

● Read docs\desktop-baseline.md
  └ 164 lines read

我已确认分层和 local 探针边界仍在 Infrastructure。下一步直接抓终端事实：先验证 SDK/restore/build/run 能不能在这台机上落地，再决定是补代码还是只收阻断证据。

● Grep "acceptance|验收|phase 2|stage 2|local mode|gateway-daemon|start orchestration" in docs\**\*
(C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\OverviewPage.axaml
  └ 56 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\SessionsPage.axaml
  └ 58 lines read

● Capture dotnet SDK and runtime info
  $ Set-Location 'C:\Users\kukisama\Downloads\Project\longxia'; dotnet --list-sdks; '' ; dotnet
  --info
  └ 15 lines...

终端已经坐实：这台机仍然只有 `10.0.5` runtime、没有任何 SDK，所以任务卡第 1 项的“成功证据”在当前环境无法补齐。我继续把失败链路、local 真实探针结果和验收包文档收紧到可直接复核。

● Capture local prerequisite and probe evidence
  $ $ProgressPreference='SilentlyContinue'; Write-Host 'node:'; (Get-Command node -ErrorAction
  SilentlyContinue | Select-Object -ExpandProperty Source); Write-Host ''; Write-Host
  'openclaw:'; (Get-Command openclaw -ErrorAction SilentlyContinue | Select-Object
  -ExpandProperty Source); Write-Host ''; Write-Host 'ready:'; try { $r = Invoke-WebRequest
  -UseBasicParsing -Uri 'http://127.0.0.1:18789/ready' -TimeoutSec 5; 'STATUS ' + ...
  └ 13 lines...

● Attempt solution restore
  $ Set-Location 'C:\Users\kukisama\Downloads\Project\longxia'; dotnet restore
  .\OpenClaw.Windows.sln
  └ 8 lines...

● Attempt solution build
  $ Set-Location 'C:\Users\kukisama\Downloads\Project\longxia'; dotnet build .\OpenClaw.Windows.sln
  └ 8 lines...

● Attempt local mode run
  $ Set-Location 'C:\Users\kukisama\Downloads\Project\longxia'; $env:OPENCLAW_WINDOWS_MODE='local';
  dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 8 lines...

● Stop shell
  └ 1 line...

● Stop shell
  └ 1 line...

● Stop shell
  └ 1 line...

● Read src\OpenClaw.Windows.App\ViewModels\Pages\OverviewPageViewModel.cs
  └ 25 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  └ 64 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 97 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\SessionsPageViewModel.cs
  └ 28 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 28 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchModeResolver.cs
  └ 38 lines read

● Read src\OpenClaw.Windows.Infrastructure\ResolvedWorkbenchMode.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 81 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 86 lines read

我现在能做的真实增量主要在“证据包收口”而不是“成功运行补齐”，因为没有 SDK 根本进不了 restore/build/run。接下来我补一份阶段 2 验收文档，把当前机器上的失败链路、local 探针事实、4 页壳对应关系和阶段 3 首批接入点一起固化。

● Read src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 18 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.App\Program.cs
  └ 19 lines read

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

● Read src\OpenClaw.Windows.Application\OpenClaw.Windows.Application.csproj
  └ 7 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 13 lines read

我准备做一处低风险补强：把“start orchestration 仍缺”直接做成 Diagnostics 的显式信号，避免 local 真跑起来后只看到 attach/health 成功却看不见未完项。然后把当前机器的终端证据和阶段 3 预热点固化进验收文档。

● Edit src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  Edit docs\desktop-baseline.md
  Create docs\stage2-acceptance-package.md

● Todo started: run-validation

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 126 lines read

● Read docs\stage2-acceptance-package.md
  └ 205 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 89 lines read

● Grep "Gateway start orchestration|No \.NET SDKs were found|gateway-daemon|OPENCLAW_WINDOWS_MODE"
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 5 lines found

● Todo started: tighten-evidence

● Read docs\desktop-baseline.md lines 135-160
  └ 26 lines read

● List docs files
  $ Set-Location 'C:\Users\kukisama\Downloads\Project\longxia'; Get-ChildItem -Recurse -File docs |
  Select-Object FullName
  └ 5 lines...

最后做一个小清理并收尾：把 mock 诊断里的格式瑕疵修正一下，然后结束为可交付的 `PARTIAL` 验收状态。

● Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs

● Todo completed: final-verify

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs lines 69-89
  └ 21 lines read

STATUS: PARTIAL

SUMMARY:
<<<SUMMARY
本轮把阶段2材料收成了可核查的最小验收包，并补强了 local/mock 诊断口径：现在文档和诊断都明确表述“local 已有真实 PATH + attach/health probe，start/repair orchestration 仍未实现且留在 `IGatewayAdapter` 后”。同时我已留存当前机器上的真实失败链路证据，但由于这台机器仍然只有 `.NET 10.0.5 runtime`、没有 SDK，任务卡要求的 `restore/build/run` 成功硬证据仍无法完成，所以本轮只能报 `PARTIAL`，不能报阶段2完成。
SUMMARY>>>

FACTS:
<<<FACTS
1. 我留存了当前机器的真实终端证据：
   - `dotnet --list-sdks` => `No SDKs were found.`
   - `dotnet --info` => Host/Runtime `10.0.5`，仅有 runtime，无 SDK。
   - `dotnet restore .\OpenClaw.Windows.sln` => 失败，报 `No .NET SDKs were found`
   - `dotnet build .\OpenClaw.Windows.sln` => 失败，报 `No .NET SDKs were found`
   - `$env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj` => 失败，报 `No .NET SDKs were found`

2. 我留存了当前机器的 local 环境事实：
   - `node` 可解析：`C:\Program Files\nodejs\node.exe`
   - `openclaw` 当前不可解析
   - `http://127.0.0.1:18789/ready` => 连接被拒绝
   - `http://127.0.0.1:18789/healthz` => 连接被拒绝

3. 本轮改动文件：
   - `docs\stage2-acceptance-package.md`
   - `docs\desktop-baseline.md`
   - `src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs`
   - `src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs`

4. 新增的验收包 `docs\stage2-acceptance-package.md` 已收口：
   - 当前阶段结论：未完成阶段2，原因是缺 `.NET 10 SDK` 成功机证据
   - 当前机器的终端证据与 local 探针事实
   - 4 页壳在 local 模式下各自对应的真实语义
   - 最小 success / failure / empty-state 证据定义
   - 架构边界复核结果
   - 阶段3首批真实接入点清单

5. 我补强了诊断面板口径，避免“attach/health 成功”被误读成“已经具备 start orchestration”：
   - `LocalDiagnosticsAdapter` 新增显式诊断信号：`Gateway start orchestration`
   - `MockDiagnosticsAdapter` 同样新增对应诊断信号
   - 两侧都新增 `Future gateway start command = openclaw gateway-daemon` 诊断入口

6. 我复核了分层红线，未发现回渗：
   - `ServiceCollectionExtensions` 仍在 Infrastructure 选择 mock/local
   - `App.axaml.cs` 只做 DI 和窗口装配
   - `MainWindowViewModel` 仍只消费 `DesktopWorkbenchStore` 快照
   - PATH/HTTP/.NET SDK 检查仍在 Infrastructure

7. 当前仍未拿到任务卡第1项要求的“装有 `.NET 10 SDK` 的机器上的成功证据”，因此：
   - 阶段2不能宣称完成
   - 本轮产出可作为“阻断已精准定位 + 验收包已收口”的中间提交物
FACTS>>>

ADJUSTMENTS:
<<<ADJUSTMENTS
1. 主动把“start orchestration 仍缺”从隐含事实提升为 Diagnostics 的显式信号，降低后续 local 真跑时的口径混淆风险。
2. 主动新增 `docs\stage2-acceptance-package.md`，把当前可运行事实、失败链路、4 页壳语义、架构边界和阶段3预热点收成一份最小验收包。
3. 顺手把 `MockDiagnosticsAdapter` 的缩进格式整理了一下；未改动行为。
ADJUSTMENTS>>>

QUESTIONS:
<<<QUESTIONS
当前唯一关键阻塞仍是环境：这台机器没有 `.NET 10 SDK`，所以无法补齐任务卡要求的 `restore/build/run` 成功硬证据。请主线安排一台已安装 `.NET 10 SDK` 的机器，或给出该机器上的终端回传窗口；否则阶段2无法改判为完成。
QUESTIONS>>>

NEXT:
<<<NEXT
1. 在有 `.NET 10 SDK` 的机器上重跑并留存：
   - `dotnet --list-sdks`
   - `dotnet restore .\OpenClaw.Windows.sln`
   - `dotnet build .\OpenClaw.Windows.sln`
   - `$env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj`

2. 如果 local 成功跑起，再补一组最小真实运行态证据：
   - success：`openclaw` 可解析，`/ready|/readyz` 与 `/healthz|/health` 成功
   - failure：探针失败或版本不兼容
   - empty：现有 `No*` 状态在 4 页壳中的实际展示

3. 阶段3预热可直接从现有 seam 继续：
   - `IGatewayAdapter` 的 start/repair orchestration
   - `openclaw --version` 兼容检查
   - 日志路径落盘
   - 常见诊断动作入口
NEXT>>>


Total usage est:        1 Premium request
API time spent:         2m 30s
Total session time:     3m 23s
Total code changes:     +229 -4
Breakdown by AI model:
 gpt-5.4                 621.2k in, 11.4k out, 578.2k cached (Est. 1 Premium request)
