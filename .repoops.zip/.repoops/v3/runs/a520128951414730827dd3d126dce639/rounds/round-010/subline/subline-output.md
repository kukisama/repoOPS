我先快速摸清现有 `Gateway` 接缝、诊断/配置页和文档位置，再按阶段3要求落计划与改动。

● SQL: Create stage3 todos
  └ 3 row(s) inserted. Last inserted row ID: 3.

● List directory .
  └ 8 files found

● Glob "docs\**\*.md" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Grep
"IGatewayAdapter|GatewayAdapter|Diagnostics|Configuration|LocalGateway|gateway-daemon|health|attach"
 in src\**\*.cs (C:\Users\kukisama\Downloads\Project\longxia)
  └ No matches found

● Glob "src\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

第一次检索模式没打准，我改用目录浏览和更稳妥的文件名搜索把关键文件一次性捞出来。

● List directory docs
  └ 3 files found

● List directory src
  └ 3 files found

● Grep "IGatewayAdapter|Diagnostics|Configuration|gateway-daemon|attach|health" in *.axaml
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 15 lines found

● Glob "**\*.csproj" in C:\Users\kukisama\Downloads\Project\longxia
  └ 3 files found

● Grep "interface\s+IGatewayAdapter|class\s+.*Gateway.*Adapter|class\s+.*Diagnostics|class\s+.*Confi
guration|gateway-daemon|LocalGateway|health|attach" in *.cs
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 69 lines found

● Glob "**\*.md" in C:\Users\kukisama\Downloads\Project\longxia
  └ 43 files found

我已经定位到关键 seam 了：`IGatewayAdapter`、`LocalGatewayAdapter`、`LocalGatewayRuntimeInspector`，以及现有诊断/配置页文案。接下来补计划并把这些文件一次读全，避免边改边猜。

● Read src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  └ 14 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 208 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 219 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 126 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read docs\stage2-acceptance-package.md
  └ 162 lines read

✗ Read ~\.copilot\session-state\8f0136e5-19b2-4ad8-bba6-0afde839df4c\plan.md
  Path does not exist

● Todo started: stage3-implement

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 35 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Grep "record\s+GatewayControlAction|record\s+DiagnosticEntryPoint|record\s+DiagnosticSignal|record
\s+DesktopWorkbenchSnapshot|interface\s+IDiagnosticsAdapter|class\s+MainWindowViewModel|class\s+Desk
topWorkbenchService|class\s+DesktopWorkbenchStore" in *.cs
(C:\Users\kukisama\Downloads\Project\longxia)
  └ 5 files found

● Create ~\.copilot\session-state\8f0136e5-19b2-4ad8-bba6-0afde839df4c\plan.md

下一步我会把“可执行能力”做成基础设施层的自动编排：当本地模式缺服务但具备前置条件时，由适配器内部负责启动/重试并把结果投影到现有页面，不新增交互。

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 12 lines read

● Read src\OpenClaw.Windows.Application\Models\DesktopWorkbenchSnapshot.cs
  └ 97 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

✗ Grep "record\s+GatewayControlAction|record\s+DiagnosticEntryPoint|record\s+DiagnosticSignal|record
\s+BlockingItem|record\s+ReadinessProbe|record\s+DesktopConfig" in *.cs
(C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.Application)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

现有 UI 只是展示字符串卡片，这反而适合这轮：能力做在 Infrastructure，页面只接收更真实的状态、日志路径和诊断动作说明。现在去补运行编排与环境探测依赖。

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 28 lines read

● Read src\OpenClaw.Windows.Infrastructure\OpenClaw.Windows.Infrastructure.csproj
  └ 13 lines read

● Read src\OpenClaw.Windows.Infrastructure\DotNetSdkProbe.cs
  └ 65 lines read

● Read src\OpenClaw.Windows.Infrastructure\ResolvedWorkbenchMode.cs
  └ 8 lines read

✗ Grep "class\s+DotNetSdkProbe|record\s+ResolvedWorkbenchMode|OPENCLAW_WINDOWS_MODE|GatewayEndpoint"
 in *.cs (C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.Infrastructure)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● List directory src\OpenClaw.Windows.Infrastructure
  └ 13 files found

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 86 lines read

● Read WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md
  └ 66 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 89 lines read

我需要对接 upstream 事实而不是凭空发明命令，所以补查 `openclaw/openclaw` 里 `gateway-daemon` 和 Node 兼容线索，再据此写版本检查与启动参数。

● Search code: repo:openclaw/openclaw "gateway-daemon"
  └ Output too large to read at once (34.4 KB). Saved to: C:\Users\kukisama\AppDa...

● Search code: repo:openclaw/openclaw engines node OR "node >=" OR ".nvmrc"
  └ {"total_count":0,"incomplete_results":false}

● Get file or directory contents: package.json
  └ Output too large to read at once (23.3 KB). Saved to: C:\Users\kukisama\AppDa...

● Get file or directory contents: README.md
  └ Output too large to read at once (120.1 KB). Saved to: C:\Users\kukisama\AppD...

● Read ~\AppData\Local\Temp\1773501570805-copilot-tool-output-5gyy7h.txt lines 1-200
  └ 200 lines read

● Grep "gateway-daemon|doctor|Node|node 22|pnpm|npm"
(C:\Users\kukisama\AppData\Local\Temp\1773501571919-copilot-tool-output-j5xo8g.txt)
  └ 25 lines found

● Grep "gateway-daemon|doctor|engines|node|packageManager|bin|scripts"
(C:\Users\kukisama\AppData\Local\Temp\1773501570805-copilot-tool-output-5gyy7h.txt)
  └ 92 lines found

● Read ~\AppData\Local\Temp\1773501570206-copilot-tool-output-08uxb7.txt lines 1-220
  └ 1 line read

● Create src\OpenClaw.Windows.Infrastructure\LocalGatewayPathResolver.cs
  Create src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalGatewayProbeClient.cs
  Create src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  Edit src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  Edit src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  Edit src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs

代码已落下第一版实现，我先跑 `restore/build` 把编译面的问题打掉，再回头补文档与人工协作说明。

● Todo completed: stage3-investigate

● Restore and build solution
  $ dotnet restore .\OpenClaw.Windows.sln && dotnet build .\OpenClaw.Windows.sln
  └ 497 lines...

是可预期的小编译面：`LocalGatewayRuntimeInspector` 仍是 `public`，但我新注入的两个 helper 是 `internal`。我把构造函数收回到同一可见性层级，再继续 build。

● Edit src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs

● Todo started: stage3-implement

● Rebuild solution
  $ dotnet build .\OpenClaw.Windows.sln
  └ 761 lines...

编译已过。我再做一轮本地模式烟测：只验证“能启动并保持存活一小段时间”，不把它包装成视觉验收。

● SQL: Keep docs pending
  └ 1 row(s) updated.

● Smoke test local mode launch
  $ $env:OPENCLAW_WINDOWS_MODE='local'; $p = Start-Process dotnet -ArgumentList 'run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj' -WorkingDirectory (Get-Location)
  -PassThru; Start-Sleep -Seconds 10; $stillRunning = -not $p.HasExited; if ($stillRunning) {
  Stop-Process -Id $p.Id }; if ($stillRunning) { 'SMOKE_OK: app stayed running for 10 seconds in
  local mode.' } else { "SMOKE_FAIL: app exited early with code $($p.ExitCode)." }
  └ 2 lines...

烟测提示早退，我直接前台跑一次把异常抓出来，再修；这比猜 ExitCode 更靠谱。

● Todo started: stage3-implement

● Run app in local mode foreground
  $ $env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 98 lines...

前台跑通了：进程在 30 秒窗口内持续存活，没有立即异常退出。上一条 `Start-Process` 烟测是假阴性，我现在清掉前台进程并转去补文档。

● Stop shell
  └ 1 line...

● Todo started: stage3-implement

● Create 人为参与.md
  Edit docs\stage2-acceptance-package.md
  Edit WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md

文档已补，顺手把页面里的旧口径收一下，避免 UI 还写着“start/repair 未实现”这种过时说法。

● Todo started: stage3-docs

✗ Grep "Stage 2|start orchestration|start, attach, and health|start and repair|attach and health
probes|Pending implementation|Future gateway" in *.{cs,axaml}
(C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

● Edit src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  Edit src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  Edit src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml

最后一轮验证：重新 build，并再前台跑一次 local 模式，确认改完 UI 文案后没有回归。

● Todo started: stage3-docs

● Final build validation
  $ dotnet build .\OpenClaw.Windows.sln
  └ 468 lines...

● Todo completed: stage3-docs

● Final local mode smoke run
  $ $env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 98 lines...

● Stop shell
  └ 1 line...

● Todo completed: stage3-investigate, stage3-implement, stage3-docs

我补一个低成本增强：即使当前机器还没真正跑起 `openclaw`，配置/诊断页给出的日志路径也会被提前落目录，方便人工直接去找。

● Edit src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs

● Check final build after last tweak
  $ dotnet build .\OpenClaw.Windows.sln
  └ 645 lines...

STATUS: DONE
SUMMARY:
<<<SUMMARY
本轮把阶段3首批真接入落到了既有 seam 内：仅在 `IGatewayAdapter` / Infrastructure 里补了本地 `openclaw gateway-daemon` 启动、最小 `openclaw doctor` repair/retry 编排、Node/CLI 兼容检查、稳定日志路径与常见诊断动作；4 页壳未扩页，ViewModel 仍只消费快照。同时补了 `人为参与.md`，并把“自动烟测”和“人工视觉确认”在文档里明确拆开。
SUMMARY>>>
FACTS:
<<<FACTS
- 关键代码改动：
  - 新增 `src\OpenClaw.Windows.Infrastructure\LocalGatewayPathResolver.cs`
  - 新增 `src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs`
  - 新增 `src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs`
  - 新增 `src\OpenClaw.Windows.Infrastructure\LocalGatewayProbeClient.cs`
  - 新增 `src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs`
  - 修改 `src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs`
  - 修改 `src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs`
  - 修改 `src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml`
  - 修改 `src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml`
- 文档改动：
  - 新增根目录 `人为参与.md`
  - 更新 `docs\stage2-acceptance-package.md`，明确“终端 smoke 已验证 / 截图语义待人工确认”
  - 更新 `WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md`，写入 start/repair 与稳定日志路径
- 真能力事实：
  - `LocalGatewayProcessOrchestrator` 现在会在本地模式且前置条件满足时，调用 upstream CLI 进行 `gateway-daemon` 启动，并在启动未就绪时执行最小 `openclaw doctor` repair/retry
  - 进程控制、版本探测、日志路径、HTTP probe 全留在 Infrastructure，没有进 ViewModel / 页面
  - 兼容检查已接入 upstream 事实：Node 按 `>=22.16.0` 检查；CLI 读取 `openclaw --version`
  - 稳定日志路径已落为 `%LocalAppData%\OpenClaw.Windows\logs\gateway-daemon.log` 与 `gateway-repair.log`
  - Diagnostics 现有页面已能显示：启动命令、repair 命令、Node 版本检查、日志路径、tail 命令
- 验证结果：
  - `dotnet build .\OpenClaw.Windows.sln` 成功
  - 最终再次 `dotnet build .\OpenClaw.Windows.sln` 成功
  - 前台执行 `OPENCLAW_WINDOWS_MODE=local` 的 `dotnet run --project .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj` 后，进程在 30 秒窗口内持续存活，未出现“立即退出”反证
  - 中途一次 `Start-Process` 烟测出现假阴性（早退码 `-532462766`），已用前台运行复核排除
FACTS>>>
ADJUSTMENTS:
<<<ADJUSTMENTS
- 顺手把 `Configuration` / `Diagnostics` 页中的旧文案从“仅 attach/health、start 未实现”更新为当前阶段3事实口径，但未新增页面、未改 UI 架构。
- 顺手把 mock 文案同步到“local 模式拥有真实 start/repair/attach 流”，避免 mock 页口径继续误导。
- 顺手让 `LocalConfigurationStore` 提前创建配置/日志目录，确保即使当前机器没真正跑起 CLI，人工也能按页内路径直接去找日志目录。
ADJUSTMENTS>>>
QUESTIONS:
<<<QUESTIONS
无
QUESTIONS>>>
NEXT:
<<<NEXT
建议主线下一步优先做两件事：
1. 在装有真实 `openclaw` CLI 的机器上复核一次本轮 start/repair 日志链路，确认 `gateway-daemon.log` / `gateway-repair.log` 有真实内容。
2. 按 `人为参与.md` 回收 `Configuration` 与 `Diagnostics` 页的人工截图结论，重点看 start/repair/日志路径/空态与失败态是否都肉眼可辨。
NEXT>>>


Total usage est:        1 Premium request
API time spent:         7m 28s
Total session time:     9m 30s
Total code changes:     +1078 -168
Breakdown by AI model:
 gpt-5.4                 1.9m in, 36.7k out, 1.9m cached (Est. 1 Premium request)
