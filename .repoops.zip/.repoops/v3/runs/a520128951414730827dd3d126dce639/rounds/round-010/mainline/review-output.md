我先做一次轻量复核搭架：补会话计划、登记复核待办，并并行读取关键文件与目录，随后再跑构建/烟测核实子线说法。

● Todo added: Review claimed changes

● List directory .
  └ 9 files found

● Glob "src\**\*.cs" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Glob "src\**\*.axaml" in C:\Users\kukisama\Downloads\Project\longxia
  └ No matches found

● Read 人为参与.md
  └ 71 lines read

● Read WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md
  └ 68 lines read

● Read docs\stage2-acceptance-package.md
  └ 190 lines read

● Create session plan
  $ $plan = @'
  # Round 10 review plan
  1. Inspect claimed code and docs changes against the task card.
  2. Validate architecture boundaries: start/repair/compatibility/logging remain in
  Infrastructure seam....
  └ 6 lines...

我已经拿到文档侧证据了；下一步直接抽查代码边界和真实接入点，重点看 start/repair 是否还留在 Infrastructure seam 里。

● List directory src\OpenClaw.Windows.App\Views\Pages
  └ 8 files found

● List directory src\OpenClaw.Windows.Infrastructure
  └ 18 files found

● List directory src\OpenClaw.Windows.App\ViewModels\Pages
  └ 4 files found

✗ Grep "ProcessStartInfo|HttpClient|File\.|Directory\.|Environment\.|Process\.|openclaw|gateway-daem
on|doctor" (C:\Users\kukisama\Downloads\Project\longxia\src\OpenClaw.Windows.App)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

✗ Grep "gateway-daemon|openclaw doctor|--version|LOCALAPPDATA|gateway-repair|gateway-daemon\.log|Pro
cessStartInfo|StartAsync|Repair|Compatibility|Tail"
(C:\Users\kukisama\Downloads\Project\longxia\src)
  └ rg: \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 1: error parsing glob
  'bin\': dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 2: error parsing glob 'obj\':
  dangling '\'
  \\?\C:\Users\kukisama\Downloads\Project\longxia\.gitignore: line 3: error parsing glob '.vs\':
  dangling '\'

检索被 `.gitignore` 的 Windows 反斜杠写法绊了一下，我改成直接读关键文件本身，继续做边界与能力核验。

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayAdapter.cs
  └ 220 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs
  └ 313 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayCompatibilityProbe.cs
  └ 164 lines read

● Read src\OpenClaw.Windows.Infrastructure\ServiceCollectionExtensions.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs
  └ 159 lines read

● Read src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs
  └ 164 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalDiagnosticsAdapter.cs
  └ 155 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalConfigurationStore.cs
  └ 30 lines read

代码主路径基本对上了，我接着抽查 ViewModel / 页面和剩余基础设施文件，确认有没有回渗，以及页面是否只是显示既有快照。

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayPathResolver.cs
  └ 35 lines read

● Read src\OpenClaw.Windows.Infrastructure\DesktopWorkbenchService.cs
  └ 128 lines read

● Read src\OpenClaw.Windows.Infrastructure\LocalGatewayProbeClient.cs
  └ 125 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockGatewayAdapter.cs
  └ 91 lines read

● Read src\OpenClaw.Windows.Infrastructure\Mock\MockDiagnosticsAdapter.cs
  └ 93 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\ConfigurationPage.axaml
  └ 88 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs
  └ 37 lines read

● Read src\OpenClaw.Windows.App\Views\Pages\DiagnosticsPage.axaml
  └ 119 lines read

● Read src\OpenClaw.Windows.App\ViewModels\Pages\DiagnosticsPageViewModel.cs
  └ 45 lines read

文档里我发现一个值得盯住的点：`stage2-acceptance-package.md` 还保留着“start/repair 未实现”的旧阶段结论。我先不急着下结论，先跑当前构建和本地模式烟测，确认代码事实和工作区事实谁更可信。

● Todo started: review-scope

● Run app in local mode
  $ $env:OPENCLAW_WINDOWS_MODE='local'; dotnet run --project
  .\src\OpenClaw.Windows.App\OpenClaw.Windows.App.csproj
  └ 1 line...

● Build solution
  $ dotnet build .\OpenClaw.Windows.sln
  └ 514 lines...

构建已通过。现在我读取本地模式运行态，并顺手检查日志目录/文档口径是否与代码一致。

● Read docs\stage2-evidence\terminal-evidence.txt
  └ 88 lines read

● Check local logs directory
  $ $logs = Join-Path $env:LOCALAPPDATA 'OpenClaw.Windows\logs';
  $exists = Test-Path $logs;
  $items = if ($exists) { Get-ChildItem $logs | Select-Object Name,Length,LastWriteTime } else {
   @() };
  Write-Output "LOG_DIR=$logs";...
  └ 5 lines...

● Search boundary and error handling
  $ $paths = @(
    '.\src\OpenClaw.Windows.Infrastructure\LocalGatewayProcessOrchestrator.cs',
    '.\src\OpenClaw.Windows.Infrastructure\ProcessCommandRunner.cs',
    '.\src\OpenClaw.Windows.Infrastructure\LocalGatewayRuntimeInspector.cs',
    '.\src\OpenClaw.Windows.App\ViewModels\Pages\ConfigurationPageViewModel.cs',...
  └ 42 lines...

● Read shell output: Waiting up to 10 seconds for command output
  └ 131 lines...

我拿到一个真实差异点了：应用本身确实持续存活，但 `%LocalAppData%\OpenClaw.Windows\logs` 目前没有被创建，这和“目录会提前创建”这条子线说法不完全一致。我再做一次针对性复核，确认这是时序问题还是事实偏差。

● Read src\OpenClaw.Windows.App\App.axaml.cs
  └ 40 lines read

● Read src\OpenClaw.Windows.App\ViewModels\MainWindowViewModel.cs
  └ 168 lines read

● Recheck support directories
  $ $settingsDir = Join-Path $env:APPDATA 'OpenClaw.Windows';
  $logsDir = Join-Path $env:LOCALAPPDATA 'OpenClaw.Windows\logs';
  Write-Output "SETTINGS_DIR=$settingsDir EXISTS=$(Test-Path $settingsDir)";
  Write-Output "LOGS_DIR=$logsDir EXISTS=$(Test-Path $logsDir)";
  if (Test-Path $settingsDir) { Get-ChildItem $settingsDir | Select-Object ...
  └ 6 lines...

● Read shell output: Waiting up to 10 seconds for command output
  └ 131 lines...

我再补一刀状态流复核：看 `DesktopWorkbenchStore` 的调用链，判断“目录未创建”到底是初始化没走到，还是子线把事实说满了。

● Read src\OpenClaw.Windows.Application\Abstractions\IDesktopWorkbenchService.cs
  └ 8 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IGatewayAdapter.cs
  └ 14 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IDiagnosticsAdapter.cs
  └ 12 lines read

● Read src\OpenClaw.Windows.Application\State\DesktopWorkbenchStore.cs
  └ 22 lines read

● Read src\OpenClaw.Windows.Application\Abstractions\IConfigurationStore.cs
  └ 8 lines read

● Check running app process
  $ Get-Process | Where-Object { $_.ProcessName -like 'OpenClaw.Windows.App*' -or $_.MainWindowTitle
   -eq 'OpenClaw Windows Workbench' } | Select-Object
  Id,ProcessName,MainWindowTitle,HasExited,StartTime | Format-Table -AutoSize
  └ 1 line...

我基本能定性了：主路径成立，但有两个“说满了”的地方要压回去——正向 start/repair 还缺运行态取证，目录预创建这条主动调整也没被当前工作区事实证实。我收尾一下进程并整理最终判定。

● Todo started: verify-build-smoke

● Stop shell
  └ 1 line...

● Final directory state check
  $ $logsDir = Join-Path $env:LOCALAPPDATA 'OpenClaw.Windows\logs';
  $settingsDir = Join-Path $env:APPDATA 'OpenClaw.Windows';
  Write-Output "FINAL_SETTINGS_EXISTS=$(Test-Path $settingsDir)";
  Write-Output "FINAL_LOGS_EXISTS=$(Test-Path $logsDir)"
  └ 3 lines...

VERDICT: ACCEPT
GOAL_STATUS: INCOMPLETE
CONTINUE: YES
NEXT_STAGE: 阶段3：真实能力接入
NEXT_STAGE_GOAL: 在不破坏现有分层与 4 页壳的前提下，把“已落代码的 start/repair/compatibility/diagnostics”补成有正向运行证据、可回归、可解释的真实本地接入能力
NEXT_ROUND_GOAL: 补齐 `gateway-daemon` / `doctor` 正向烟测证据，修正文档与工作区事实不一致处，并把日志目录/错误暴露收口到可验证状态
SUMMARY:
<<<SUMMARY
本轮主体可收：`start/repair` 的实现确实落在 `IGatewayAdapter` / Infrastructure seam 内，未回渗到 ViewModel 或页面；4 页壳仍在，`Configuration` / `Diagnostics` 只是消费快照与更新文案。`Node >=22.16.0` 与 `openclaw --version` 兼容检查、稳定日志路径、诊断入口点也都已在代码中落下，不是纯占位。

我额外核到两处不能按子线原话全额认定：一是当前机器上只有构建成功与“local 模式进程持续存活”的烟测，没有拿到 `openclaw gateway-daemon` / `openclaw doctor` 的正向运行证据；二是工作区事实显示 `%AppData%\OpenClaw.Windows` 与 `%LocalAppData%\OpenClaw.Windows\logs` 目前并未被实际创建，所以“目录已提前创建、人工可直接去找”这条主动调整未被现状证实。

`人为参与.md` 写得清楚，自动 smoke 与人工视觉确认边界分明，这部分应正式保留。`docs\stage2-acceptance-package.md` 虽完成了 smoke/人工边界拆分，但仍保留“start/repair 未实现”的旧事实表述，作为 Stage 2 hold-point 可以理解，但现在已经与代码事实脱节，下一轮应做最小澄清。
SUMMARY>>>
CHANGE_DECISION:
<<<CHANGE_DECISION
正式保留：
- 保留 `LocalGatewayPathResolver` / `ProcessCommandRunner` / `LocalGatewayCompatibilityProbe` / `LocalGatewayProbeClient` / `LocalGatewayProcessOrchestrator` 这一组按职责拆分的 Infrastructure 方案
- 保留 `Configuration` / `Diagnostics` 在原 4 页内承载 start/repair/compatibility/log-path/diagnostic entry points 的做法
- 保留根目录 `人为参与.md`
- 保留 `WINDOWS-ENVIRONMENT-TROUBLESHOOTING.md` 中对 smoke 与人工视觉确认分离的口径

下一轮顺手修：
- 为 `openclaw gateway-daemon` 与 `openclaw doctor` 补一份正向运行证据；若真实 CLI 不可得，可用可复跑 harness 只做取证，不产品化
- 最小修正 `docs\stage2-acceptance-package.md`：保留 Stage 2 hold-point 结论，但不要继续写成“当前仍未实现 start/repair”
- 要么让配置/日志目录在实际启动路径上真的预创建，要么撤回相关口径，避免文档先于事实
- 顺手收紧 `ProcessCommandRunner` / orchestrator 中的静默 catch，至少别把失败吞成无痕

冻结不再扩散：
- 不新增页面
- 不把进程控制/网络/配置写回渗到 ViewModel
- 不做截图自动判读承诺
- 不把当前 process orchestrator 继续堆成更大的单点服务
CHANGE_DECISION>>>
NEXT_TASK_CARD:
<<<NEXT_TASK_CARD
1. 阻断先修：补 `gateway-daemon` 与 `doctor` 的正向 smoke 证据，证明 start/repair 不只是代码存在，而是可跑、可留痕、可复核。
2. 顺手修正文档：`stage2-acceptance-package.md` 只做最小澄清，明确“Stage 2 结论是历史 hold-point；Stage 3 已把 start/repair 落到 seam 内”，继续保留 smoke/人工视觉分界。
3. 兑现或回退“目录预创建”口径：让 `%AppData%` / `%LocalAppData%` 支撑路径真的落地，或删改相关说法。
4. 非阻断并入：把关键失败原因从静默 catch 改成可诊断输出，继续只留在 Infrastructure。
NEXT_TASK_CARD>>>
NEXT_REVIEW_FOCUS:
<<<NEXT_REVIEW_FOCUS
1. 是否拿到了 `openclaw gateway-daemon` / `openclaw doctor` 的真实正向运行证据，而不只是负向阻断或文案展示
2. 日志/配置目录是否已与文档口径一致，可被人工按页内路径直接找到
3. `stage2-acceptance-package.md` 是否完成了“历史结论保留、当前事实不失真”的最小澄清
4. 错误处理是否仍然可诊断，且没有把进程控制重新扩散进 UI 层
NEXT_REVIEW_FOCUS>>>


Total usage est:        1 Premium request
API time spent:         2m 21s
Total session time:     3m 4s
Total code changes:     +0 -0
Breakdown by AI model:
 gpt-5.4                 451.7k in, 9.7k out, 400.5k cached (Est. 1 Premium request)
