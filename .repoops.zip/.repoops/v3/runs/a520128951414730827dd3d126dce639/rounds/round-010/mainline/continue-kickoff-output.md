STATUS: PLAN
STAGE_PLAN:
<<<STAGE_PLAN
无
STAGE_PLAN>>>
CURRENT_STAGE: 阶段3：真实能力接入
STAGE_GOAL: 在不破坏现有分层、4 页壳与 Infrastructure seam 的前提下，把阶段3从“代码已落地”推进到“`start/repair` 有正向证据、目录路径真实落地、失败可诊断、现有 UI 全中文”。
ARCH_GUARDRAILS:
<<<ARCH_GUARDRAILS
1. 技术栈红线：桌面端固定为 `.NET 10 + Avalonia`，UI 采用现代桌面风格；不要中途漂移到 WinUI / Electron / MAUI。  
2. 产品边界红线：Windows 端继续定位为 OpenClaw 的原生桌面工作台/伴生端，而不是全量替代 upstream Node/TS 平台。  
3. 分层红线：UI（Views/ViewModels）与接入层（Gateway/API/进程/配置适配）必须隔离，禁止把网络、进程控制、配置读写直接塞进 ViewModel。  
4. 集成红线：优先“对接 upstream 能力”而非“重写 upstream 能力”；能走 Gateway / 现有协议 / 本地进程编排，就不要先做 C# 侧重构版内核。  
5. 结构红线：按模块拆分，避免继续堆成单点大类或全局 God Service；状态管理保持可替换、可测试。  
6. 数据红线：本地持久化先从轻量配置与缓存做起；未出现明确需求前，不引入重型数据库。  
7. 体验红线：先统一导航、主题、设计 token、状态反馈和空态/错误态，再叠功能；不要先堆功能再补 UI。  
8. 文案红线：从下一轮起，所有桌面端用户可见 UI 文案默认统一为中文；内部变量、类型名、协议字段、CLI 原生命令名可保留英文，但界面上必须给中文表达或中文说明。
ARCH_GUARDRAILS>>>
ROUND_GOAL: 用一轮把阶段3剩余阻断项收口，并把现有桌面端用户可见 UI 做到全中文一致。
TASK_CARD:
<<<TASK_CARD
1. 阻断先修：为 `openclaw gateway-daemon` 与 `openclaw doctor` 补齐正向 smoke 证据，证明 `start/repair` 不只是代码存在而是真能跑、能留痕、能复核。优先跑真实 CLI；若当前环境确实缺依赖，可加“仅用于取证的可复跑 harness/脚本”，但不得产品化、不得新增页面、不得改动既有分层。证据至少包含：触发命令、前置条件、退出码/存活状态、日志落点、复跑步骤。  

2. 阻断先修：兑现或回退“目录预创建”口径。优先让 `%AppData%\OpenClaw.Windows` 与 `%LocalAppData%\OpenClaw.Windows\logs` 在实际启动/诊断路径上真实落地；若事实仍不成立，同轮删改相关文档与界面说法，不得继续写成“已预创建、用户可直接去找”。  

3. 阻断先修：收紧 Infrastructure 内的静默失败处理。围绕 `ProcessCommandRunner`、process orchestrator、compatibility/diagnostic 相关实现，把关键失败转成可诊断输出：至少可见错误摘要、退出码、stderr 或路径提示；继续只留在 seam / Infrastructure 内，不把进程控制、命令拼接或配置写回塞进 ViewModel。  

4. 同轮并入：完成现有桌面端用户可见 UI 的中文化清扫。范围覆盖现有 4 页壳、导航标题、按钮、状态标签、空态/错误态、诊断/配置提示、日志与兼容检查结果文案。内部变量、类名、接口名可继续英文；CLI 原生命令名与协议关键字可保留英文，但界面必须用中文说明其含义。不得新增页面，不单开 i18n 大基建。  

5. 文档最小修正：`docs\stage2-acceptance-package.md` 仅做必要澄清，明确“Stage 2 结论是历史 hold-point；Stage 3 已把 `start/repair` 落到 seam 内，正向 smoke 证据另列”；继续严格区分“自动烟测通过”和“人工视觉确认待回传”。同步更新根目录 `人为参与.md`，新增中文 UI 核验所需的截图/观察项。  

6. 验证策略：本轮自动化仍以 build + smoke 为主，只验证 `gateway-daemon` / `doctor` / 目录落地 / log-path / 中文文案回归，不写视觉结论；人工只回传截图与观察，不承诺自动截图判读。若某个 UI 文案来自 upstream 原文或系统返回值，需标明来源与处理策略，避免后续继续混英文。
TASK_CARD>>>
REVIEW_FOCUS:
<<<REVIEW_FOCUS
1. 是否拿到了可复核的 `gateway-daemon` / `doctor` 正向 smoke 证据，而非仅有“代码实现存在”。  
2. `%AppData%` / `%LocalAppData%` 目录口径是否已与运行事实一致。  
3. Infrastructure 里的关键失败是否仍有静默吞错。  
4. 现有 4 页与共享组件里是否还有漏网英文，尤其导航、空态、错误态、诊断与配置面。
REVIEW_FOCUS>>>
SUMMARY:
<<<SUMMARY
值得继续推进。当前轮次虽已把阶段3核心能力落进正确 seam，方向是对的，但目标状态仍是 `INCOMPLETE`：缺的是“可复核证据、运行事实一致、失败可诊断、界面中文统一”这四块收口，而不是重做架构。下一轮应先把这四项一次性补齐；做完后，阶段3就接近可收口，后续可更顺滑转入阶段4的发布化与体验抛光。
SUMMARY>>>


Total usage est:        1 Premium request
API time spent:         41s
Total session time:     45s
Total code changes:     +0 -0
Breakdown by AI model:
 gpt-5.4                 21.2k in, 3.1k out, 15.9k cached (Est. 1 Premium request)
